export class Customers {
    "first_name": String;
    "last_name": String;
    "customer_id": 100004;
    "status": String;
    "account_number": String;
    "acc_type_id": Number;
    "branch_id": Number;
    "branch_name": String;
    "account_type": String
}