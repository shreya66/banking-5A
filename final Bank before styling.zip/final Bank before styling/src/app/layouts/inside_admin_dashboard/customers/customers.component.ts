import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../../../_services/authentication.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {
  userList: any = [];

  constructor(private authService: AuthenticationService,
    private router: Router) { }

  ngOnInit() { 
    if(localStorage.role=="ytrewq"){
      this.router.navigate(['/website']);
    }
    console.log(">><<<<");
    this.getUsers('');
  }

  getUsers(value) {
    console.log('value', value)
    this.userList = [];
    var obj = {};
    if(value == 'Webdunia'){
      obj['branch_name'] = 'Webdunia'
    }
   else if(value == 'Diaspark'){
      obj['branch_name'] = 'Diaspark'
    }
    else {
      obj['branch_name'] = ''
    }
    this.authService.getUsers(obj).subscribe((data: any) => {
      console.log(data);
      this.userList = data;
    });
  }

 





}
  







// delete(item) {
  //   var deletedIndex;
  //   for (let index = 0; index < this.userList.length; index++) {
  //     if(item==this.userList[index]['account_number']){
  //       deletedIndex=index;
  //     }
  //   }
  //   delete this.userList[deletedIndex];
  //   this.authService.delete(item).subscribe((data: String) => {
  //     // console.log(data);

     
  //     this.userList = data;
  //   });
  // }


  // delete() {

  //   console.log(account_number);
  //   this.authService.post(account_number)
  //     .subscribe
  //     (data => console.log(account_number))
  // }

  // delete(email: string) {

  //   console.log(email);
  //   this.authService.delete(email)
  //     .subscribe
  //     (data => console.log(email))
  // }












