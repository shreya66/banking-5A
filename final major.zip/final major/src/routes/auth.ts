import * as express from "express";
const bodyParser = require('body-parser');
import auth from '../controllers/auth'
var router = express.Router();
router.use(bodyParser.json());


router.post('/token', async (req, res) => {
  try {
    console.log('we are here')
    console.log(req.headers)
    var output = await auth.getJwtToken(req.body,req.headers)
    console.log('-----------------')
    res.send(output)
  } catch (err) {
    res.send(err)
  }
})

module.exports = router;
