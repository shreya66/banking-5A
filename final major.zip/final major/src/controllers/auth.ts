import tables from '../enums/tb_config'
import authService from '../services/authService'
import * as _ from "lodash";
var validation = require('../enums/utility');
const dbAction = require('../models/sqlModel')


export default class {

    static async getJwtToken(req,header) {
        try {
           
                let val1 = { device_id :  _.get(header , 'device_id', ""), user_agent :  _.get(header , 'user_agent', "") }
                if(val1.device_id == "") { return validation.error({}, 'Device_id required', 400)  }
                if(val1.user_agent == "") { return validation.error({}, 'user_agent required', 400)  }
        
                var uuid = await authService.encrypt(val1.device_id)
                const token = await authService.createToken(uuid)
                 
                  return validation.success('Success', { token: token }, 200);
            }
        
        catch (error) {
            console.log(error)
            return error;
        }
    }
    static async check_acc(account_number) {
        try {

                const result = await dbAction.getRecords(tables.customer_account, 'status', `account_number = '${account_number}' `, '')

                if(result.length && result[0].status=="Active"){
                    return true;
                }

                else if(account_number == 1000000000)
                return true;

                else
                return false
           
            }
        
        catch (error) {
            console.log(error)
            return error;
        }
    }
}