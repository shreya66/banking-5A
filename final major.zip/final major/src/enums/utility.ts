var  success = function(message = null, data = null, code = 200) {
    let outputData = data;
    const status = {
        code: code,
        message: message
    };
    return Object.assign({}, "", { 
        assets : data,
        status : status
    } );
}
var error = function(assets = [], message = null, code = 400) {
    const status = {
        code: code,
        message: message
    };
    if (message.code)
        status.code = message.code; //TODO: remove it later, upon better implementation (need to send error code along with message)
    if (message.message)
        status.message = message.message; //TODO: remove it later, upon better implementation (need to send error code along with message)
    if (!message)
        status.message = 'ERROR';

}

module.exports.error = error;
module.exports.success = success;