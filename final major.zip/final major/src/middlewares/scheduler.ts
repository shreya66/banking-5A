import * as express from "express";
const bodyParser = require('body-parser');
import user from '../controllers/user'
var router = express.Router();
router.use(bodyParser.json());
const dbAction = require('../models/sqlModel');
import tables from '../enums/tb_config'

export default class {
    static async check_current() {
        try {

            const result_current = await dbAction.getRecords(tables.account, 'account_balance,account_number,account_overdraft', `acc_type_id = 2 AND status = 'Active'`, '');
            let length_current = result_current.length;
            let i_current = 0;
            const interest_current = 2;

            while (length_current) {
              
                if (parseInt(result_current[i_current].account_balance) < 0 ) {


                    let interest_current_now = (parseInt(result_current[i_current].account_balance) * (interest_current / 100));

                    let updated_balance = parseInt(result_current[i_current].account_balance) + interest_current_now;
                    let updated_overdraft = parseInt(result_current[i_current].account_overdraft) + interest_current_now;

                    const output2 = await dbAction.updateRecords(tables.account, 'account_balance = ?', 'account_number = ?',
                        [updated_balance, result_current[i_current].account_number]);

                    const output3 = await dbAction.updateRecords(tables.account, 'account_overdraft = ?', 'account_number = ?',
                        [updated_overdraft, result_current[i_current].account_number]);
 
                    if(updated_overdraft<0){
                        const output3 = await dbAction.updateRecords(tables.account, 'account_overdraft = ?', 'account_number = ?',
                        [0, result_current[i_current].account_number]);

                    }


                }

                length_current--;
                i_current++;

            }


        }

        catch (error) {

            return error;

        }

    }

    static async check_savings() {
        try {

            const interest_savings = 14;
            const result_savings = await dbAction.getRecords(tables.account, 'account_balance,account_number', `acc_type_id = 1 AND status = 'Active'`, '');

            let length_savings = result_savings.length;
            let minimum_limit = 5000;
            let penalty = 100;
            let i_savings = 0;
            while (length_savings) {

                if (parseInt(result_savings[i_savings].account_balance) < minimum_limit) {


                    let updated_balance = parseInt(result_savings[i_savings].account_balance) - penalty;

                    const output = await dbAction.updateRecords(tables.account, 'account_balance = ?', 'account_number = ?',
                        [updated_balance, result_savings[i_savings].account_number]);

                    const result_savings_2 = await dbAction.getRecords(tables.account, 'account_balance,account_number', `acc_type_id = 1 AND status = 'Active'`, '');

                    let updated_balance_final = parseInt(result_savings_2[i_savings].account_balance) + (parseInt(result_savings_2[i_savings].account_balance) * (interest_savings / 100));

                    const output2 = await dbAction.updateRecords(tables.account, 'account_balance = ?', 'account_number = ?',
                        [updated_balance_final, result_savings_2[i_savings].account_number]);

                    if (parseInt(result_savings_2[i_savings].account_balance) <= 0) {
                        const output = await dbAction.updateRecords(tables.account, 'account_balance = ?', 'account_number = ?',
                            [0, result_savings_2[i_savings].account_number]);

                    }

                }

                else {

                    let updated_balance = parseInt(result_savings[i_savings].account_balance) + (parseInt(result_savings[i_savings].account_balance) * (interest_savings / 100));

                    const output = await dbAction.updateRecords(tables.account, 'account_balance = ?', 'account_number = ?',
                        [updated_balance, result_savings[i_savings].account_number]);

                }

                length_savings--;
                i_savings++;

            }



        }

        catch (error) {

            return error;



        }

    }

}
