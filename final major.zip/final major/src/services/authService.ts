import * as jwt from 'jsonwebtoken';
const crypto = require('crypto');
import * as _ from "lodash";
var validation = require('../enums/utility');

export default class {
    static async verifyToken(token: any) {
        try {
            console.log('Reached verifyToken');
            const decoded: any = jwt.verify(token, "env.jwt.secret");
            return decoded;
        } catch (error) {
            console.log('error in auth/verifytoken');
            return false;
        }
    }

    static async createToken(payload: any) {
        try {

            console.log('Reached createToken');
            const access_token = jwt.sign(payload, "env.jwt.secret");
            return access_token;
        } catch (error) {
            console.log('Error in auth/createToken', error);
            return validation.error({}, error,400);
        }
    }

    static async encrypt(data) { 
        try {
            console.log('Reached encrypt');
            let random =  Math.floor((Math.random() * 100000000000000) + 1);
            let cipher = crypto.createCipher('aes-256-cbc',random.toString());  
            let encrypted = cipher.update(data);
            encrypted = Buffer.concat([encrypted, cipher.final()]);
            return { uuid: encrypted.toString('hex') };
        } catch (error) {
            console.log("==================Catch++++++++++++++++")
            return validation.error({}, error,400);
        }
    }

    static async decryptToken(token) {
        try {
            console.log('Reached decryptToken');
            const decoded: any = jwt.verify(token, "env.jwt.secret");
            var uuid = decoded['uuid'];
            var account_number = decoded['account_number']
            let payload = {uuid,account_number}
            return payload;
        } catch (error) {
            return validation.error({}, error,400);
        }
    }

    static async encryptPass(pass) {
        try {
            var crypto = require('crypto');
            var hash = crypto.createHash('sha256')
               .update(pass)
               .digest('hex');
               console.log(hash);
               return hash;

        } catch (error) {
            return validation.error({}, error,400);
        }
    }

    
}