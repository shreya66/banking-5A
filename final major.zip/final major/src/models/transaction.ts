var _ = require('underscore');
// var db = require("./index");
var connection = require("./index");
var trCon = require("./index");
import authService from '../services/authService'
const dbAction = require('./sqlModel');
let acc = 100001;
module.exports ={

      async transaction (table1,table2, 
        where = '') 
        
        {
          console.log(connection);
           connection.connect();
          //   connection.connec(function(err) {
          //       if (err) {
          //         console.error('error connecting: ' + err.stack);
          //         return;
          //       }
          //       console.log('connected as id ' + connection.threadId);
          //     });
               
              /* Begin transaction */
              connection.beginTransaction(async function(err) {
                if (err) { throw err; }
                try{
               const result = await dbAction.getRecords(table1, '*', `email = '${where}' `,'');
               const output = await dbAction.insertRecords(table2, 'first_name,last_name,address,pinCode,phone_number,userName,password,email,city,state,aadhaarNumber,account_number', "?,?,?,?,?,?,?,?,?,?,?,?",
                        [result[0].first_name,result[0].last_name,result[0].address,result[0].pinCode,
                        result[0].phone_number,result[0].userName,result[0].password,result[0].email,
                        result[0].city,result[0].state,result[0].aadhaarNumber,acc]);
               const output2 = dbAction.deleteRecords(table1,`email = '${where}' `,'');
                }
                catch(error){
                  if (err) { 
                    connection.rollback(function() {
                      throw err;
                    });
                }
                else{
                  connection.end();
                }
              }
          
                // connection.query('YOUR QUERY', "PLACE HOLDER VALUES", function(err, result) {
                //   if (err) { 
                //     connection.rollback(function() {
                //       throw err;
                //     });
                //   }
               
                //   const log = result.insertId;
               
                //   connection.query('ANOTHER QUERY PART OF TRANSACTION', log, function(err, result) {
                //     if (err) { 
                //       connection.rollback(function() {
                //         throw err;
                //       });
                //     }  
                //     connection.commit(function(err) {
                //       if (err) { 
                //         connection.rollback(function() {
                //           throw err;
                //         });
                //       }
                //       console.log('Transaction Completed Successfully.');
                //       connection.end();
                //     });
                //   });
                // });
              });
        //     console.log("--------------------",trCon.trCon);
        //  var chain = trCon.trCon.chain();

        //  chain.
        //  on('commit', function(){
        //  console.log('number commit');
        //  }).
        //  on('rollback', function(err){
        //  console.log(err);
        //  });

        //  chain.
        //      query(`SELECT * from ${table1} WHERE email = ${where}`).on('result', async function(result){
        //          let pass = await authService.encryptPass(result[0].password);
        //          const output = await dbAction.insertRecords(table2, 'first_name,last_name,address,pinCode,phone_number,userName,password,email,city,state,aadhaarNumber,account_number', "?,?,?,?,?,?,?,?,?,?,?,?",
        //                      [result[0].first_name,result[0].last_name,result[0].address,result[0].pinCode,
        //                      result[0].phone_number,result[0].userName,pass,result[0].email,
        //                      result[0].city,result[0].state,result[0].aadhaarNumber,acc])
        //                      acc++;
        //        }).on("result",async function(result){
        //         const output2 = await dbAction.deleteRecords(table3,`email = '${where}' `,'');
        //        }).on('result', function(result){
        //      chain.commit();
        //  }).autoCommit(false);
// return new Promise((resolve,reject)=>{
//     connection.getConnection(function(err, connection) {
//         connection.beginTransaction(function(err) {
//             if (err) { //Transaction Error (Rollback and release connection)
//                 connection.rollback(function() {
//                     connection.release();
//                     reject( err);
//                 });
//             }
//             connection.query(`SELECT * from ${table1} WHERE email = ${where}`).on('result', async function(result){
//                 if (err) {       //Why is this here?
//                     reject(err);
//                 }
//                 if (error) { //Query Error (Rollback and release connection)
//                     connection.rollback(function() {
//                         connection.release();
//                         reject( err);
//                     });
//                 } else if (result[0] !== 'undefined') {
//                     const output = await dbAction.insertRecords(table2, 'first_name,last_name,address,pinCode,phone_number,userName,password,email,city,state,aadhaarNumber,account_number', "?,?,?,?,?,?,?,?,?,?,?,?",
//                     [result[0].first_name,result[0].last_name,result[0].address,result[0].pinCode,
//                     result[0].phone_number,result[0].userName,result[0].password,result[0].email,
//                     result[0].city,result[0].state,result[0].aadhaarNumber,acc])
//                     acc++;
//                     resolve(output);
//                 } else {
//                     reject(error);
//                 }
//                 connection.commit(function(commitErr) {
//                     if (commitErr) {
//                         connection.rollback(function() {
//                             connection.release();
//                             reject(commitErr);
//                         });
//                     }
//                     connection.release();
//                 });
//             });
//         });
//       });
      


// })
        
    }

}