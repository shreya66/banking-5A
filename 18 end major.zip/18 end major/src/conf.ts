'use strict';

module.exports.config = function(){
	const conf = process.env.STAGE||'dev'
	console.log("Env :",conf)
	return require('./config/'+conf)
};
