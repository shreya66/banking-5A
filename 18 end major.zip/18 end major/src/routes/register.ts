import * as express from "express";
const bodyParser = require('body-parser');
import register from '../controllers/register'
var router = express.Router();
router.use(bodyParser.json());

// router.get('/check', async (req, res) => {
//     try {
      
//       var output = await register.check(req.body,req.query);
    
//           res.send(output);
  
//     } catch (err) {
//       res.send(err);
//     }
//   })

  // router.post('/email', async (req, res) => {
  //   try {
      
  //     var output = await register.available_email(req.body,req.headers);
    
  //         res.send(output);
  
  //   } catch (err) {
  //     res.send(err);
  //   }
  // })

  // router.post('/phone', async (req, res) => {
  //   try {
      
  //     var output = await register.available_phone(req.body,req.headers);
    
  //         res.send(output);
  
  //   } catch (err) {
  //     res.send(err);
  //   }
  // })

  router.post('/submit', async (req, res) => {
    try {
      
      var output = await register.submit(req.body,req.headers);
    
          res.send(output);
  
    } catch (err) {
      res.send(err);
    }
  })
  
  module.exports = router;