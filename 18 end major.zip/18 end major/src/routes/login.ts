import * as express from "express";
const bodyParser = require('body-parser');
import login from '../controllers/login'
var router = express.Router();
router.use(bodyParser.json());


router.post('/', async (req, res) => {
  try {
    
    var output = await login.validate(req.body,req.headers);
        res.json(output);

  } catch (err) {
    res.send(err);
  }
})

module.exports = router;