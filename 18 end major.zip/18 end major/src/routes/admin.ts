import * as express from "express";
const bodyParser = require('body-parser');
import admin from '../controllers/admin'
import tokenValidator from "../middlewares/tokenValidator";
var router = express.Router();
router.use(bodyParser.json());


router.post('/approval', async (req, res) => {
    try {
      
      var output = await admin.approve(req.body,req.query);
    
          res.json(output);
  
    } catch (err) {
      res.json(err);
    }
  })

  router.post('/add_money',tokenValidator,async (req, res) => {
    try {
      
      var output = await admin.add_money(req.body,req.headers);
    
          res.json(output);
  
    } catch (err) {
      res.json(err);
    }
  })
  
  router.post('/close', async (req, res) => {
    try {
      
      var output = await admin.close(req.body,req.headers);
    
          res.json(output);
  
    } catch (err) {
      res.json(err);
    }
  })

  router.post('/transactions', async (req, res) => {
    try {
      
      var output = await admin.transactions(req.body,req.headers);
    
          res.json(output);
  
    } catch (err) {
      res.json(err);
    }
  })
  
  router.post('/list', async (req, res) => {
    try {
      
      var output = await admin.list(req.body,req.headers);
    
          res.json(output);
  
    } catch (err) {
      res.json(err);
    }
  })

  router.post('/unlock', async (req, res) => {
    try {
      
      var output = await admin.unlock(req.body,req.headers);
    
          res.json(output);
  
    } catch (err) {
      res.json(err);
    }
  })

  router.post('/check_cheque', async (req, res) => {
    try {
      
      var output = await admin.check_cheque(req.body,req.headers);
    
          res.json(output);
  
    } catch (err) {
      res.json(err);
    }
  })

  
  module.exports = router;