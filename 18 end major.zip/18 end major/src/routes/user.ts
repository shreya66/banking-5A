import * as express from "express";
const bodyParser = require('body-parser');
import user from '../controllers/user'
var router = express.Router();
router.use(bodyParser.json());

router.post('/send_money', async (req, res) => {
    try {
      
      var output = await user.send_money(req.body,req.headers);
    
          res.json(output);
  
    } catch (err) {
      res.json(err);
    }
  })

  router.post('/transactions', async (req, res) => {
    try {
      
      var output = await user.transactions(req.body,req.headers);
    
          res.json(output);
  
    } catch (err) {
      res.json(err);
    }
  })

  router.post('/cheque', async (req, res) => {
    try {
      
      var output = await user.cheque(req.body,req.headers);
    
          res.json(output);
  
    } catch (err) {
      res.json(err);
    }
  })

  module.exports = router;