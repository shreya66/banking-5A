import * as express from "express";
const bodyParser = require('body-parser');
import admin from '../controllers/admin'
import tokenValidator from "../middlewares/tokenValidator";
var router = express.Router();
router.use(bodyParser.json());
import login from '../controllers/login'
import register from '../controllers/register'
import user from '../controllers/user'
import auth from '../controllers/auth'


/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});


router.post('/approval', async (req, res) => {
  try {
    
    var output = await admin.approve(req.body,req.query);
  
        res.json(output);

  } catch (err) {
    res.json(err);
  }
})

router.post('/add_money',tokenValidator,async (req, res) => {
  try {
    
    var output = await admin.add_money(req.body,req.headers);
  
        res.json(output);

  } catch (err) {
    res.json(err);
  }
})

router.post('/close', async (req, res) => {
  try {
    
    var output = await admin.close(req.body,req.headers);
  
        res.json(output);

  } catch (err) {
    res.json(err);
  }
})

router.post('/transactions', async (req, res) => {
  try {
    
    var output = await admin.transactions(req.body,req.headers);
  
        res.json(output);

  } catch (err) {
    res.json(err);
  }
})

router.post('/list', async (req, res) => {
  try {
    
    var output = await admin.list(req.body,req.headers);
  
        res.json(output);

  } catch (err) {
    res.json(err);
  }
})

router.post('/unlock', async (req, res) => {
  try {
    
    var output = await admin.unlock(req.body,req.headers);
  
        res.json(output);

  } catch (err) {
    res.json(err);
  }
})

router.post('/check_cheque', async (req, res) => {
  try {
    
    var output = await admin.check_cheque(req.body,req.headers);
  
        res.json(output);

  } catch (err) {
    res.json(err);
  }
})


router.post('/login', async (req, res) => {
  try {
    
    var output = await login.validate(req.body,req.headers);
        res.json(output);

  } catch (err) {
    res.send(err);
  }
})

router.post('/submit', async (req, res) => {
  try {
    
    var output = await register.submit(req.body,req.headers);
  
        res.send(output);

  } catch (err) {
    res.send(err);
  }
})


router.post('/send_money', async (req, res) => {
  try {
    
    var output = await user.send_money(req.body,req.headers);
  
        res.json(output);

  } catch (err) {
    res.json(err);
  }
})

router.post('/transactions', async (req, res) => {
  try {
    
    var output = await user.transactions(req.body,req.headers);
  
        res.json(output);

  } catch (err) {
    res.json(err);
  }
})

router.post('/cheque', async (req, res) => {
  try {
    
    var output = await user.cheque(req.body,req.headers);
  
        res.json(output);

  } catch (err) {
    res.json(err);
  }
})

router.post('/token', async (req, res) => {
  try {
    console.log('we are here')
    console.log(req.headers)
    var output = await auth.getJwtToken(req.body,req.headers)
    console.log('-----------------')
    res.send(output)
  } catch (err) {
    res.send(err)
  }
})


module.exports = router;
