import * as Joi from '@hapi/joi'
import tables from '../enums/tb_config'
import authService from '../services/authService'
import * as _ from "lodash";
import verify from '../controllers/auth'
var validation = require('../enums/utility');
const dbAction = require('../models/sqlModel');
import moment from 'moment'
let uuid = require("uuid");

export default class{

static async send_money(req,header){

    try{
        console.log("===========================================REACHED SEND MONEY=====================================")
        const schema = Joi.object().keys({
            account_number: Joi.string().min(10).max(10).required(),
            receiver_account_number:Joi.string().min(10).max(10).required(),
            money:Joi.number().integer().min(1).max(100000).required()
        }).with('account_number',['receiver_account_number','money']);
        const { error, value } = Joi.validate(req, schema, { abortEarly: false });
        if (error) {
            console.log(error.details[0].message);
            return {
                status: "error",
                message: error.details[0].message
            }

        };

        try{
            let val1 = { receiver_account_number: _.get(req, 'receiver_account_number', ""), account_number: _.get(req, 'account_number', ""),money: _.get(req, 'money', "") }
            const check = await verify.check_acc(val1.account_number);
            const check1  = await verify.check_acc(val1.receiver_account_number);
            if(check && check1 ){
                console.log("===========================================REACHED CHECK=====================================")

                const result = await dbAction.getRecords(tables.account, 'account_number,acc_type_id,account_balance,account_overdraft', `account_number = '${val1.account_number}' `, '')


                if(parseInt(result[0].account_balance)< val1.money && result[0].acc_type_id == 1){

                    return{
                        code:400,
                        status:"error",
                        message:"Not enough funds"
                    }
                
                }

                else if(parseInt(result[0].account_balance) == 0 && result[0].acc_type_id == 2){

                    if(result[0].account_overdraft<val1.money){
                        return {
                            code:401,
                        status:"error",
                        message:"Not enough funds and Overdraft limit reached"
                        }
                    }

                    else{
                        let updated_overdraft = parseInt(result[0].account_overdraft) - parseInt(val1.money);
                        const result5 = await dbAction.getRecords(tables.account, 'account_balance', `account_number = '${val1.account_number}' `, '')
                        let updated_balance = parseInt(result5[0].account_balance)- parseInt(val1.money);

                        console.log("===========================================REACHED ELSE====================================")

                        const output = await dbAction.updateRecords(tables.account, 'account_balance = ?', 'account_number = ?',
                        [updated_balance, val1.account_number]);

                        const output2 = await dbAction.updateRecords(tables.account, 'account_overdraft = ?', 'account_number = ?',
                        [updated_overdraft, val1.account_number]);

                        const result1 = await dbAction.getRecords(tables.account, 'account_balance', `account_number = '${val1.receiver_account_number}' `, '')

                        let updated_balance_receiver = parseInt(result1[0].account_balance) + parseInt(val1.money) ;

                        const output3 = await dbAction.updateRecords(tables.account, 'account_balance = ?', 'account_number = ?',
                        [updated_balance_receiver, val1.receiver_account_number]);

                        let trans_id = uuid.v4();
                        let reference_id = uuid.v4();
    
                        const output4 = await dbAction.insertRecords(tables.transaction, 'transaction_id,transaction_timestamp,transaction_amt,account_number,receiver_account_number,mode,reference_id', "?,?,?,?,?,?,?",
                        [trans_id, moment().format('YYYY-MM-DD HH:mm:ss'), val1.money,val1.account_number, val1.receiver_account_number, "Net Banking", reference_id]);

                        return{
                            code:200,
                            status:"success",
                            message: `${val1.money} successfully transferred to ${val1.receiver_account_number}`
                        }

                    }

                }

               else if(result[0].acc_type_id == 2 && parseInt(result[0].account_balance)<val1.money ){

                    let total_balance = parseInt(result[0].account_balance) + parseInt(result[0].account_overdraft)
    
                    if(total_balance<val1.money){

                        return {
                            code:401,
                        status:"error",
                        message:"Not enough funds and Overdraft limit reached"
                        }

                    }

                    else{

                        let remaining_balance = parseInt(val1.money) - parseInt(result[0].account_balance);
                        let updated_overdraft = parseInt(result[0].account_overdraft) - remaining_balance;

                        const output3 = await dbAction.updateRecords(tables.account, 'account_balance = ?', 'account_number = ?',
                            [-remaining_balance, val1.account_number]);

                            const output4 = await dbAction.updateRecords(tables.account, 'account_overdraft = ?', 'account_number = ?',
                            [updated_overdraft, val1.account_number]);

                            const result1 = await dbAction.getRecords(tables.account, 'account_balance', `account_number = '${val1.receiver_account_number}' `, '')

                            let updated_balance_receiver = parseInt(result1[0].account_balance) + parseInt(val1.money) ;

                            const output5 = await dbAction.updateRecords(tables.account, 'account_balance = ?', 'account_number = ?',
                            [updated_balance_receiver, val1.receiver_account_number]);

                            let trans_id = uuid.v4();
                            let reference_id = uuid.v4();
        
                            const output6 = await dbAction.insertRecords(tables.transaction, 'transaction_id,transaction_timestamp,transaction_amt,account_number,receiver_account_number,mode,reference_id', "?,?,?,?,?,?,?",
                            [trans_id, moment().format('YYYY-MM-DD HH:mm:ss'), val1.money,val1.account_number, val1.receiver_account_number, "Net Banking", reference_id]);

                            return{
                                code:200,
                                status:"success",
                                message: `${val1.money} successfully transferred to ${val1.receiver_account_number}`
                            }


                    }

                    

                }

                else{


                    let updated_balance = parseInt(result[0].account_balance) - parseInt(val1.money);
    
                    const output = await dbAction.updateRecords(tables.account, 'account_balance = ?', 'account_number = ?',
                        [updated_balance, val1.account_number]);

                    const result1 = await dbAction.getRecords(tables.account, 'account_balance', `account_number = '${val1.receiver_account_number}' `, '')

                    let updated_balance_receiver = parseInt(result1[0].account_balance) + parseInt(val1.money) ;

                    const output2 = await dbAction.updateRecords(tables.account, 'account_balance = ?', 'account_number = ?',
                            [updated_balance_receiver, val1.receiver_account_number]);

                            let trans_id = uuid.v4();
                            let reference_id = uuid.v4();
        
                            const output4 = await dbAction.insertRecords(tables.transaction, 'transaction_id,transaction_timestamp,transaction_amt,account_number,receiver_account_number,mode,reference_id', "?,?,?,?,?,?,?",
                            [trans_id, moment().format('YYYY-MM-DD HH:mm:ss'), val1.money,val1.account_number, val1.receiver_account_number, "Net Banking", reference_id]);

                            return{
                                code:200,
                                status:"success",
                                message: `${val1.money} successfully transferred to ${val1.receiver_account_number}`
                            }

                }

            }

            else{
                return {
                    code:402,
                status:"error",
                message:"invalid Account Number or Account inactive"
                }
                
            }
            

        }
        catch(error){
            return {
                code:403,
            status:"error",
            message:"Database Error"
            }
        }


    }
    catch(error){

        return {
            code:403,
        status:"error",
        message:"Input Error"
        }


    }
}

static async transactions(req,header){

    try{
        const schema = Joi.object().keys({
            account_number: Joi.string().min(10).max(10).required(),
            receiver_account_number:Joi.string().min(10).max(10).required(),
            money:Joi.number().integer().min(1).max(100000).required()
        }).with('account_number',['receiver_account_number','money']);
        const { error, value } = Joi.validate(req, schema, { abortEarly: false });
        if (error) {
            console.log(error.details[0].message);
            return {
                status: "error",
                message: error.details[0].message
            }

        };

        try{
            let val1 = { account_number: _.get(req, 'account_number', "") }
            const check = await verify.check_acc(val1.account_number);

            if(check ){
        const result5 = await dbAction.getRecords(tables.transaction, '*', `account_number = '${val1.account_number}' `, '')
        return result5;
        }
        else{
            return{
                code:400,
                status:"error",
                message:"Account Inactive"
            }
        }
    }
        catch(error){

            return{
                code:402,
                status:"error",
                message:"Database Error"
            }
            

        }
    }

    catch(error){
        return{
            code:403,
            status:"error",
            message:"Input Error"
        }


    }


}

static async cheque(req,header){

    try{
        const schema = Joi.object().keys({
            payer_account_number: Joi.string().min(10).max(10).required(),
            payee_account_number: Joi.string().min(10).max(10).required(),
            payee_first_name: Joi.string().required(),
            payee_last_name: Joi.string().required(),
            amount:Joi.number().integer().min(1).max(100000).required(),
            cheque_number: Joi.string().required()
        }).with('payer_account_number',['payee_account_number','payee_first_name','payee_last_name','amount','cheque_number']);
        const { error, value } = Joi.validate(req, schema, { abortEarly: false });
        if (error) {
            console.log(error.details[0].message);
            return {
                status: "error",
                message: error.details[0].message
            }

        };

        try{
            let val1 = { payer_account_number: _.get(req, 'payer_account_number', ""), payee_account_number: _.get(req, 'payee_account_number', ""), payee_first_name: _.get(req, 'payee_first_name', ""), payee_last_name: _.get(req, 'payee_last_name', ""), amount: _.get(req, 'amount', ""), cheque_number: _.get(req, 'cheque_number', "")}
 
            const output4 = await dbAction.insertRecords(tables.cheque, 'cheque_number,payer_account_number,payee_account_number,payee_first_name,payee_last_name,amount,cheque_status,submission_date', "?,?,?,?,?,?,?,?",
            [val1.cheque_number,val1.payer_account_number,val1.payee_account_number,val1.payee_first_name,val1.payee_last_name,val1.amount,"sent for clearance",moment().format('YYYY-MM-DD HH:mm:ss')]);

            return{
                code:402,
                status:"success",
                message:"Slip Generated Successfully"
            }
    }
        catch(error){

            return{
                code:402,
                status:"error",
                message:"Database Error"
            }
            

        }
    }

    catch(error){
        return{
            code:403,
            status:"error",
            message:"Input Error"
        }


    }


}




}