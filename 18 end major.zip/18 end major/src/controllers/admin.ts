import tables from '../enums/tb_config'
import authService from '../services/authService'
import check_acc from '../controllers/auth'
import * as _ from "lodash";
import * as Joi from '@hapi/joi'
import moment from 'moment'
import { join } from 'path';
import verify from '../controllers/auth'
// import { connection } from '../models';
var validation = require('../enums/utility');
const dbAction = require('../models/sqlModel');
const transaction = require("../models/transaction");
var trCon = require("./../models/index");
let uuid = require("uuid");
let acc = "1000000001"

const interest_rate = 14;
const overdraft = 50000;
export default class {

    static async approve(req, query) {

        try {
            const schema = Joi.object().keys({
                aadhaarNumber: Joi.string().min(12).max(12).required(),
                account_type:Joi.string().required(),
                branch_name:Joi.string().required()
            }).with('customer_id', ['password','account_type','branch_name']);
            const { error, value } = Joi.validate(req, schema, { abortEarly: false });
            if (error) {
                console.log(error.details[0].message);
                return {
                    status: "error",
                    message: error.details[0].message
                }

            };
            let val1 = { aadhaarNumber: _.get(req, 'aadhaarNumber', ""), branch_name: _.get(req, 'branch_name', ""), account_type: _.get(req, 'account_type', "") };
            let val2 = { status: _.get(query, 'status', "") };
            if (val2.status == "accept") {

                try {
                            console.log("========================================REACHED SUBMIT=======================================");
                    const result = await dbAction.getRecords(tables.users, '*', `aadhaarNumber = '${val1.aadhaarNumber}' `, '')

                    if (result.length && result[0].status == "Active") {
                        console.log(result[0].status)
                        console.log("========================================REACHED IF=======================================");
                        const result2 = await dbAction.getRecords(tables.branch, 'branch_id', `branch_name = '${val1.branch_name}' `, '')
                        const result3 = await dbAction.getRecords(tables.account_type, 'acc_type_id', `account_type = '${val1.account_type}' `, '')
                        const result4 = await dbAction.getRecords(tables.customer_account, 'account_number', ``, '')
                        if(result4.length){
                            let length = result4.length
                            acc = (parseInt(result4[length-1].account_number)+1).toString();
                             
                        }
                        
                        const output = await dbAction.insertRecords(tables.customer_account, 'customer_id,account_number,creation_time,status,branch_id,acc_type_id', "?,?,?,?,?,?",
                            [result[0].customer_id, acc, moment().format('YYYY-MM-DD HH:mm:ss'), "Active", result2[0].branch_id, result3[0].acc_type_id])
                        if (result3[0].acc_type_id == 1) {
                            const output2 = await dbAction.insertRecords(tables.account, 'account_number,acc_type_id,account_balance,account_interest_rate,account_overdraft,status', "?,?,?,?,?,?",
                                [acc, result3[0].acc_type_id, 0, interest_rate, 0,"Active"]);
                        }
                        else if (result3[0].acc_type_id == 2) {
                            const output2 = await dbAction.insertRecords(tables.account, 'account_number,acc_type_id,account_balance,account_interest_rate,account_overdraft,status', "?,?,?,?,?,?",
                                [acc, result3[0].acc_type_id, 0, 0, overdraft,"Active"]);

                        }
                        const output3 = dbAction.deleteRecords(tables.application, `aadhaarNumber = '${val1.aadhaarNumber}' AND branch_name = '${val1.branch_name}' AND account_type = '${val1.account_type}' `, '');


                    }
                    else {
                        console.log("========================================REACHED ELSE=======================================");
                        const result = await dbAction.getRecords(tables.application, '*', `aadhaarNumber = '${val1.aadhaarNumber}' `, '')
                        const output = await dbAction.insertRecords(tables.users, 'first_name,last_name,address,pincode,phone_number,password,email,city,state,aadhaarNumber,status,user_creation_time', "?,?,?,?,?,?,?,?,?,?,?,?",
                            [result[0].first_name, result[0].last_name, result[0].address, result[0].pincode,
                            result[0].phone_number, result[0].password, result[0].email,
                            result[0].city, result[0].state, result[0].aadhaarNumber, "Active", moment().format('YYYY-MM-DD HH:mm:ss')])
                        const result2 = await dbAction.getRecords(tables.users, 'customer_id,user_creation_time', `aadhaarNumber = '${val1.aadhaarNumber}' `, '')
                        const result3 = await dbAction.getRecords(tables.branch, 'branch_id', `branch_name = '${val1.branch_name}' `, '')
                        const result4 = await dbAction.getRecords(tables.account_type, 'acc_type_id', `account_type = '${val1.account_type}' `, '')
                        const result5 = await dbAction.getRecords(tables.customer_account, 'account_number', ``, '')
                        if(result5.length){
                            let length = result5.length
                            acc = (parseInt(result5[length-1].account_number)+1).toString();
                             
                        }
                        const output2 = await dbAction.insertRecords(tables.customer_account, 'customer_id,account_number,creation_time,status,branch_id,acc_type_id', "?,?,?,?,?,?",
                            [result2[0].customer_id, acc, result2[0].user_creation_time, "Active", result3[0].branch_id, result4[0].acc_type_id])

                            if (result4[0].acc_type_id == 1) {
                                const output2 = await dbAction.insertRecords(tables.account, 'account_number,acc_type_id,account_balance,account_interest_rate,account_overdraft,status', "?,?,?,?,?,?",
                                    [acc, result4[0].acc_type_id, 0, interest_rate, 0,"Active"]);
                            }
                            else if (result4[0].acc_type_id == 2) {
                                const output2 = await dbAction.insertRecords(tables.account, 'account_number,acc_type_id,account_balance,account_interest_rate,account_overdraft,status', "?,?,?,?,?,?",
                                    [acc, result4[0].acc_type_id, 0, 0, overdraft,"Active"]);
    
                            }

                            const output3 = dbAction.deleteRecords(tables.application, `aadhaarNumber = '${val1.aadhaarNumber}' AND branch_name = '${val1.branch_name}' AND account_type = '${val1.account_type}' `, '');
                        

                    }
                   

                    //  const result = await transaction.transaction(tables.application,tables.users,val1.email);
                    return {
                        code: 200,
                        status: "success",
                        message: "Accepted"
                    }

                }
                catch (error) {
                    console.log(error);
                    return {
                        code: 403,
                        status: "error",
                        message: "Error in getting records"
                    }
                }
            }

            else {
                try {
                    const output2 = await dbAction.deleteRecords(tables.application, `aadhaarNumber = '${val1.aadhaarNumber}' `, '');
                    //  const result = await transaction.transaction(tables.application,tables.users,tables.application,val1.email)
                    return {
                        code: 200,
                        status: "success",
                        message: "Application Deleted"
                    }

                }
                catch (error) {
                    console.log(error);
                    return {
                        code: 403,
                        status: "error",
                        message: "Error in deleting user application"
                    }
                }




            }




        }

        catch (error) {
console.log(error);
            return {
                code: 403,
                status: error,
                message: "Server Error"
            }

        }


    }

    static async add_money(req, header) {
        try {

            try {

                const schema = Joi.object().keys({
                    receiver_account_number: Joi.string().min(10).max(10).required(),
                    money: Joi.number().integer().min(500).max(100000).required(),
                    mode: Joi.string().required(),
                    reference_id: Joi.string().required()
                }).with('receiver_account_number', ['money','mode','reference_id']);
                const { error, value } = Joi.validate(req, schema, { abortEarly: false });
                if (error) {
                    return {
                        status: "error",
                        message: error.details[0].message
                    }

                };
              
                let val1 = { receiver_account_number: _.get(req, 'receiver_account_number', ""), money: _.get(req, 'money', ""), mode: _.get(req, 'mode', ""), reference_id: _.get(req, 'reference_id', "") };
           
                const result1 = await dbAction.getRecords(tables.account, 'status,account_balance', `account_number = '${val1.receiver_account_number}' `, '')

                if(result1[0].status == "Active")
                {
                    if(parseInt(result1[0].account_balance)<0){

                        const result = await dbAction.getRecords(tables.account, 'account_number,account_balance', `account_number = '${val1.receiver_account_number}' `, '')

                        let updated_balance = parseInt(result[0].account_balance) + parseInt(val1.money);

                        const output = await dbAction.updateRecords(tables.account, 'account_balance = ?', 'account_number = ?',
                        [updated_balance, result[0].account_number]);

                        let new_balance = updated_balance + 50000;
                        if(new_balance>0){
                            const output = await dbAction.updateRecords(tables.account, 'account_overdraft = ?', 'account_number = ?',
                            [new_balance, result[0].account_number]);
                        }

                        let trans_id = uuid.v4();
    
                        const output2 = await dbAction.insertRecords(tables.transaction, 'transaction_id,transaction_timestamp,transaction_amt,account_number,receiver_account_number,mode,reference_id', "?,?,?,?,?,?,?",
                            [trans_id, moment().format('YYYY-MM-DD HH:mm:ss'), val1.money,1000000000, val1.receiver_account_number, val1.mode, val1.reference_id]);
    

                        return {
                            code: 200,
                            status: "success",
                            message: `${val1.money} added successfully to Account:${val1.receiver_account_number}`
                        }

                    }
                    const result = await dbAction.getRecords(tables.account, 'account_number,account_balance', `account_number = '${val1.receiver_account_number}' `, '')

                    let updated_balance = parseInt(result[0].account_balance) + parseInt(val1.money);
    
                    const output = await dbAction.updateRecords(tables.account, 'account_balance = ?', 'account_number = ?',
                        [updated_balance, result[0].account_number]);
    
                    let trans_id = uuid.v4();
    
                    const output2 = await dbAction.insertRecords(tables.transaction, 'transaction_id,transaction_timestamp,transaction_amt,account_number,receiver_account_number,mode,reference_id', "?,?,?,?,?,?,?",
                        [trans_id, moment().format('YYYY-MM-DD HH:mm:ss'), val1.money,1000000000, val1.receiver_account_number, val1.mode, val1.reference_id]);

                        return {
                            code: 200,
                            status: "success",
                            message: `${val1.money} added successfully to Account:${val1.receiver_account_number}`
                        }
                }



                else{

                    return {
                        code: 403,
                        status: "error",
                        message: `Account:${val1.receiver_account_number} is Inactive`
                    }

                }

               

            }
            catch (error) {
                console.log(error);
                return {
                    code: 403,
                    status: "error",
                    message: "Error in adding funds"
                }
            }



        }

        catch (error) {

            return {
                code: 403,
                status: error,
                message: "Input Error"
            }

        }

    }

    static async close(req,header){

        try{
            const schema = Joi.object({
                account_number: Joi.string().min(10).max(10).required()
            })
            const { error, value } = Joi.validate(req, schema, { abortEarly: false });
            if (error) {
                return {
                    code:403,
                    status: "error",
                    message: error.details[0].message
                }

            };

            let val1 = { account_number: _.get(req, 'account_number', "") };

            try{
                const output = await dbAction.updateRecords(tables.customer_account, 'status = ?', 'account_number = ?',
                    ["Inactive", val1.account_number]);

                const output2 = await dbAction.updateRecords(tables.account, 'status = ?', 'account_number = ?',
                    ["Inactive", val1.account_number]);

                const result = await dbAction.getRecords(tables.customer_account, 'customer_id', `account_number = '${val1.account_number}'`, '')
                const result2 = await dbAction.getRecords(tables.customer_account, '*', `customer_id = '${result[0].customer_id}' AND status = 'Active' `, '')
                
                if(!result2.length){
                    const output = await dbAction.updateRecords(tables.users, 'status = ?', 'customer_id = ?',
                        ["Inactive", result[0].customer_id]);
                }


                    return{
                        code:200,
                        status:"success",
                        message:"Account Deactivated Successfully"
                    }
            }
            catch(error){
                return{

                code:403,
                status: "error",
                message: "Account does not exist or is already deactivated"

                }

            }



        }

        catch(e){

            return {
                code:403,
                status:error,
                message:"Input Error"
            }

        }

    }

    static async list(req,header){
        try{
           
            let val1 = { branch_name: _.get(req, 'branch_name', "") };

            try{
                const result4 = await dbAction.join(val1.branch_name);
                return result4;
            }

            catch(error){

                return{
                    code:400,
                    status:"error",
                    message:error
                }

            }


        }

        catch(error){

            return{
                code:400,
                status:"error",
                message:"Input Error"
            }



        }


    }

    static async transactions(req,header){
        try{
            const schema = Joi.object({
                account_number: Joi.string().min(10).max(10).required()
            })
            const { error, value } = Joi.validate(req, schema, { abortEarly: false });
            if (error) {
                console.log(error.details[0].message);
                return {
                    status: "error",
                    message: error.details[0].message
                }

            };
            let val1 = { account_number: _.get(req, 'account_number', "") };

            try{
                const result4 = await dbAction.getRecords(tables.transaction, '*', `account_number = ${val1.account_number}`, '')
                return result4;

            }

            catch(error){

                return{
                    code:400,
                    status:"error",
                    message:"Database Error"
                }
    
            }


        }

        catch(error){

            return{
                code:400,
                status:"error",
                message:"Input Error"
            }



        }


    }

    static async unlock(req,header){
        try{
            const schema = Joi.object({
                customer_id: Joi.string().min(6).max(8).required()
            })
            const { error, value } = Joi.validate(req, schema, { abortEarly: false });
            if (error) {
                console.log(error.details[0].message);
                return {
                    status: "error",
                    message: error.details[0].message
                }

            };
            let val1 = { customer_id: _.get(req, 'customer_id', "") };

            try{
                
                const output = await dbAction.updateRecords(tables.users, 'locked = ?', 'customer_id = ?',
                [0, val1.customer_id]);

                return{
                    code:200,
                    status:"success",
                    message:`Customer id:${val1.customer_id} unlocked successfully`
                }
        
            }

            catch(error){

                return{
                    code:400,
                    status:"error",
                    message:"Database Error"
                }
    
            }


        }

        catch(error){

            return{
                code:400,
                status:"error",
                message:"Input Error"
            }



        }


    }

    static async check_cheque(req,header){
        try{
            const schema = Joi.object().keys({
                payer_account_number: Joi.string().min(10).max(10).required(),
                payee_account_number: Joi.string().min(10).max(10).required(),
                payee_first_name: Joi.string().required(),
                payee_last_name: Joi.string().required(),
                amount:Joi.number().integer().min(1).max(100000).required(),
                cheque_number: Joi.string().required()
            }).with('payer_account_number',['payee_account_number','payee_first_name','payee_last_name','amount','cheque_number']);
            const { error, value } = Joi.validate(req, schema, { abortEarly: false });
            if (error) {
                console.log(error.details[0].message);
                return {
                    status: "error",
                    message: error.details[0].message
                }

            };
            let val1 = { payer_account_number: _.get(req, 'payer_account_number', ""), payee_account_number: _.get(req, 'payee_account_number', ""), payee_first_name: _.get(req, 'payee_first_name', ""), payee_last_name: _.get(req, 'payee_last_name', ""), amount: _.get(req, 'amount', ""), cheque_number: _.get(req, 'cheque_number', "")}

            try{
                const check = await verify.check_acc(val1.payer_account_number);
                const check1  = await verify.check_acc(val1.payee_account_number);
                if(check){
                    if(check1){
                        const result = await dbAction.getRecords(tables.account, 'acc_type_id,account_balance', `account_number = '${val1.payer_account_number}' `, '')
                        if(parseInt(result[0].account_balance)<val1.amount)
                        {
                            let penalty = 100;

                            let updated_balance = parseInt(result[0].account_balance) - penalty;

                            if(updated_balance<0 && result[0].acc_type_id == 1){
                                const output = await dbAction.updateRecords(tables.account, 'account_balance = ?', 'account_number = ?',
                                [0, val1.payer_account_number]);

                            }
                            else{
                                const output = await dbAction.updateRecords(tables.account, 'account_balance = ?', 'account_number = ?',
                            [updated_balance, val1.payer_account_number]);

                            }

                            const output3 = await dbAction.updateRecords(tables.cheque, 'cheque_status = ?', 'cheque_number = ?',
                            ["Bounced", val1.cheque_number]);
                            const output4 = await dbAction.updateRecords(tables.cheque, 'rejected_date = ?', 'cheque_number = ?',
                            [moment().format('YYYY-MM-DD HH:mm:ss'), val1.cheque_number]);

                            return{
                                code:401,
                                status:"error",
                                message:"Cheque Bounced due to Insufficient Funds"
            
                            }
                        }

                        else{

                            const result23 = await dbAction.getRecords(tables.customer_account, 'customer_id', `account_number = '${val1.payee_account_number}' `, '')
                            const result24 = await dbAction.getRecords(tables.users, 'first_name,last_name', `customer_id = '${result23[0].customer_id}' `, '')

                            if(result24[0].first_name != val1.payee_first_name || result24[0].last_name != val1.payee_last_name){

                                const output3 = await dbAction.updateRecords(tables.cheque, 'cheque_status = ?', 'cheque_number = ?',
                            ["Bounced", val1.cheque_number]);
                            const output4 = await dbAction.updateRecords(tables.cheque, 'rejected_date = ?', 'cheque_number = ?',
                            [moment().format('YYYY-MM-DD HH:mm:ss'), val1.cheque_number]);

                                return {
                                    code:401,
                                    status:"error",
                                    message:"Cheque Bounced due to Wrong Details"
                                }

                            }

                            console.log("===========================================================")
                            let updated_balance = parseInt(result[0].account_balance) - val1.amount;
                            const output = await dbAction.updateRecords(tables.account, 'account_balance = ?', 'account_number = ?',
                            [updated_balance, val1.payer_account_number]);

                            const result2 = await dbAction.getRecords(tables.account, 'account_balance', `account_number = '${val1.payee_account_number}' `, '')

                            let updated_balance2 = parseInt(result2[0].account_balance) + parseInt(val1.amount);
                            console.log("--------------------------------------",updated_balance2)

                            const output2 = await dbAction.updateRecords(tables.account, 'account_balance = ?', 'account_number = ?',
                            [updated_balance2, val1.payee_account_number]);

                            const output3 = await dbAction.updateRecords(tables.cheque, 'cheque_status = ?', 'cheque_number = ?',
                            ["Cleared", val1.cheque_number]);
                            const output4 = await dbAction.updateRecords(tables.cheque, 'approved_date = ?', 'cheque_number = ?',
                            [moment().format('YYYY-MM-DD HH:mm:ss'), val1.cheque_number]);
                            let trans_id = uuid.v4();
                            const output5 = await dbAction.updateRecords(tables.cheque, 'transaction_id = ?', 'cheque_number = ?',
                            [trans_id, val1.cheque_number]);

                            return{
                                code:200,
                                status:"success",
                                message:"Cheque Cleared "
            
                            }
                        }
                    }
                    else{
                        return{
                            code:401,
                            status:"error",
                            message:"Payee Account Inactive"
        
                        }

                    }
                

                
            }

            else{
                return{
                    code:401,
                    status:"error",
                    message:"Payer Account Inactive"

                }
            }
        
            }

            catch(error){

                return{
                    code:400,
                    status:"error",
                    message:"Database Error"
                }
    
            }


        }

        catch(error){

            return{
                code:400,
                status:"error",
                message:"Input Error"
            }



        }


    }

}