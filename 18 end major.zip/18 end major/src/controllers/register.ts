import * as Joi from '@hapi/joi'
import tables from '../enums/tb_config'
import authService from '../services/authService'
import * as _ from "lodash";
import { Http2SecureServer } from 'http2';
var validation = require('../enums/utility');
const dbAction = require('../models/sqlModel');
var uuid = require('uuid-v4');
import moment from 'moment'

export default class {

    static async submit(req, header) {
        try {
            const schema = Joi.object().keys({
                password: Joi.string().regex(/^[a-zA-Z0-9]{6,16}$/).min(6).required(),
                first_name: Joi.string().required(),
                last_name: Joi.string().required(),
                city: Joi.string().required(),
                state: Joi.string().required(),
                address: Joi.string().required(),
                pincode: Joi.string().required(),
                aadhaarNumber: Joi.string().min(12).max(12).required(),
                phone_number: Joi.string().trim().regex(/^[0-9]{7,10}$/).required(),
                email: Joi.string().email({ minDomainSegments: 2 }),
                branch_name: Joi.string().required(),
                account_type: Joi.string().required()
            });

            const { error, value } = Joi.validate(req, schema, { abortEarly: false });
            if (error) {
                console.log(error.details[0].message);
                return {
                    status: "error",
                    message: error.details[0].message
                }

            };
            let val1 = {
                password: _.get(req, 'password', ""),
                first_name: _.get(req, 'first_name', ""),
                last_name: _.get(req, 'last_name', ""),
                city: _.get(req, 'city', ""),
                state: _.get(req, 'state', ""),
                address: _.get(req, 'address', ""),
                pincode: _.get(req, 'pincode', ""),
                phone_number: _.get(req, 'phone_number', ""),
                aadhaarNumber: _.get(req, 'aadhaarNumber', ""),
                email: _.get(req, 'email', ""),
                account_type: _.get(req, 'account_type', ""),
                branch_name: _.get(req, 'branch_name', "")
            }


            try {
                const result = await dbAction.getRecords(tables.application, '*', `aadhaarNumber = '${val1.aadhaarNumber}' AND branch_name = '${val1.branch_name}' AND account_type = '${val1.account_type}' `, '')

                if (result.length) {

                    return {
                        code: 403,
                        status: "error",
                        message: `User with Aadhaar Number: ${val1.aadhaarNumber} already applied for account type:${val1.account_type} in branch: ${val1.branch_name}`

                    }

                }

                const result2 = await dbAction.getRecords(tables.users, 'customer_id,status', `aadhaarNumber = '${val1.aadhaarNumber}' `, '')

                if (result2.length && result2[0].status == "Active") {
                    const result3 = await dbAction.getRecords(tables.customer_account, 'acc_type_id,branch_id,status', `customer_id = '${result2[0].customer_id}' `, '')
                    const result4 = await dbAction.getRecords(tables.account_type, 'acc_type_id', `account_type = '${val1.account_type}' `, '')
                    const result5 = await dbAction.getRecords(tables.branch, 'branch_id', `branch_name = '${val1.branch_name}' `, '')
                    const result6 = await dbAction.getRecords(tables.customer_account, '*', `customer_id = '${result2[0].customer_id}' AND acc_type_id = '${result4[0].acc_type_id}' AND branch_id = '${result5[0].branch_id}' AND status = 'Active'  `, '')


                    if (result6.length) {


                        return {
                            code: 402,
                            status: "error",
                            message: `User with customer id:${result2[0].customer_id} already exist with same account type:${val1.account_type} in branch: ${val1.branch_name}`

                        }


                    }




                    let pass = await authService.encryptPass(val1.password);
                    const output = await dbAction.insertRecords(tables.application, 'first_name,last_name,address,pincode,phone_number,password,email,city,state,aadhaarNumber,branch_name,account_type', "?,?,?,?,?,?,?,?,?,?,?,?",
                        [val1.first_name, val1.last_name, val1.address, val1.pincode, val1.phone_number,
                            pass, val1.email, val1.city,
                        val1.state, val1.aadhaarNumber, val1.branch_name, val1.account_type])

                    return {
                        code: 200,
                        status: "success",
                        message: "Details Submitted. Awaiting admin approval"
                    }


                }

                else {
                    console.log("=====================================IN ELSE")
                    let pass = await authService.encryptPass(val1.password);
                    const output = await dbAction.insertRecords(tables.application, 'first_name,last_name,address,pincode,phone_number,password,email,city,state,aadhaarNumber,branch_name,account_type', "?,?,?,?,?,?,?,?,?,?,?,?",
                        [val1.first_name, val1.last_name, val1.address, val1.pincode, val1.phone_number,
                            pass, val1.email, val1.city,
                        val1.state, val1.aadhaarNumber, val1.branch_name, val1.account_type])

                    return {
                        code: 200,
                        status: "success",
                        message: "Details Submitted. Awaiting admin approval"
                    }


                }




            } catch (error) {

                return {
                    code: 403,
                    status: "error",
                    message: "Error in Inserting records"
                }
            }


        }

        catch (error) {
            console.log(error);
            return {
                code: 403,
                status: error,
                message: "Server Error"
            }
        }
    }

}

