
var _ = require('underscore');
var db = require("./index");
// var trCon = require("./../models/index");

module.exports =
    {
        getRecords: async (table, fields, where = '', whereParams = '') => {
            try {
                return new Promise(async (resolve, reject) => {
                    let responseObj = {};
                    if (_.isEmpty(fields)) {
                        fields = '*';
                    }

                    // if (_.isEmpty(where)) {
                    //     where = 'id != "" ';
                    // }
                    let sql = `SELECT ${fields} from ${table} WHERE ${where}`;
                    if (_.isEmpty(where)) {
                        sql = `SELECT ${fields} from ${table}`;
                    }
                    console.log("Get SQL query " + sql)
                    try {
                        const [articleRow, articleFields] = await db.connection.execute(sql, [whereParams]);
                        console.log("data in getrecords---",articleRow);
                        return resolve(articleRow);
                    }
                    catch (error) {
                        console.log("hiiiiiiiiiii" + error)
                        return reject("No data");
                    }

                });
            }
            catch (error) {
                console.log("--------------" + error)
                return await error;
            }
        },


        insertRecords: async (table, params, quesParam, values) => {
            try {
                return new Promise(async (resolve, reject) => {
                    let responseObj = {};

                    let sql = `INSERT into ${table} (${params}) VALUES (${quesParam})`;
                    console.log("Get SQL query " + sql)
                    try {
                        const [articleRow, articleFields] = await db.connection.execute(sql, values);
                        console.log( articleRow)
                        return resolve(articleRow);
                    }
                    catch (error) {
                        console.log(error)
                        return reject(error);
                    }
                })
            }
            catch (error) {
                return await error;
            }
        },

        updateRecords: async (table, setParams, where, values) => {
            try {
                return new Promise(async (resolve, reject) => {
                    let responseObj = {};

                    let sql = `UPDATE ${table} SET ${setParams} WHERE ${where}`;
                    console.log("Get SQL query " + sql)
                    try {
                        const [articleRow, articleFields] = await db.connection.execute(sql, values);
                        console.log("Get query response " + articleRow)
                        return resolve(articleRow);
                    }
                    catch (error) {
                        console.log(error)
                        return reject(error);
                    }
                })
            }
            catch (error) {
                return await error;
            }

        },

        deleteRecords: async (table, where) => {
            try {
                return new Promise(async (resolve, reject) => {
                    let responseObj = {};
                    let sql = `DELETE FROM ${table} WHERE ${where}`;
                    try {
                        db.connection.query(sql, async (err, result) => {

                            if (err) {
                                // reject(responseCode.dbErrorResponse(err));
                            }
                            else (!_.isEmpty(result))
                            {
                                //responseObj = await responseCode.recordDeleteSuccessResponse(result);
                            }
                            resolve(responseObj);
                        })
                    }
                    catch (error) {
                        return await error;
                    }

                });
            }
            catch (error) {
                return await error;
            }
        },

        uploadFile: async (uploadedFile, image_name) => {
            try {
                return new Promise(async (resolve, reject) => {
                    if (uploadedFile.mimetype === 'image/png' || uploadedFile.mimetype === 'image/jpeg' || uploadedFile.mimetype === 'image/gif') {
                        try {
                            uploadedFile.mv(`public/assets/img/${image_name}`, async (err) => {
                                if (err) {
                                    reject(err);
                                }
                                resolve('file uploaded succesfully');
                            })
                        }
                        catch (error) {
                            return await error;
                        }
                    }
                })

            }
            catch (error) {
                return await error;
            }
        },
        join: async (where) => {
            try {
                return new Promise(async (resolve, reject) => {
          if(!where){
            let sql = `SELECT first_name,last_name,u.customer_id,c.status,u.status,account_number,c.acc_type_id,c.branch_id,b.branch_name,a.account_type
            FROM customer_account c
            INNER JOIN users u
            ON c.customer_id = u.customer_id 
            INNER JOIN branch b
            ON b.branch_id = c.branch_id
            INNER JOIN account_type a
            ON a.acc_type_id = c.acc_type_id
            WHERE c.status = "Active" AND u.status = "Active"`;

            console.log("Get SQL query " + sql)
                    try {
                        const [articleRow, articleFields] = await db.connection.execute(sql);
                        console.log("data in getrecords---",articleRow);
                        return resolve(articleRow);
                    }
                    catch (error) {
                        console.log("hiiiiiiiiiii" + error)
                        return reject("No data");
                    }

          }

          if(where == "Diaspark"){

            let sql2 = `SELECT first_name,last_name,u.customer_id,c.status,u.status,account_number,c.acc_type_id,c.branch_id,b.branch_name,a.account_type
            FROM customer_account c
            INNER JOIN users u
            ON c.customer_id = u.customer_id 
            INNER JOIN branch b
            ON b.branch_id = c.branch_id
            INNER JOIN account_type a
            ON a.acc_type_id = c.acc_type_id
            WHERE c.status = "Active" AND u.status = "Active" AND b.branch_name = "Diaspark"`;

            console.log("Get SQL query " + sql2)
                    try {
                        const [articleRow, articleFields] = await db.connection.execute(sql2);
                        console.log("data in getrecords---",articleRow);
                        return resolve(articleRow);
                    }
                    catch (error) {
                        console.log("hiiiiiiiiiii" + error)
                        return reject("No data");
                    }


          }

          if(where = "Webdunia"){

            let sql3 = `SELECT first_name,last_name,u.customer_id,c.status,u.status,account_number,c.acc_type_id,c.branch_id,b.branch_name,a.account_type
            FROM customer_account c
            INNER JOIN users u
            ON c.customer_id = u.customer_id 
            INNER JOIN branch b
            ON b.branch_id = c.branch_id
            INNER JOIN account_type a
            ON a.acc_type_id = c.acc_type_id
            WHERE c.status = "Active" AND u.status = "Active" AND b.branch_name = "Webdunia"`;

            console.log("Get SQL query " + sql3)
                    try {
                        const [articleRow, articleFields] = await db.connection.execute(sql3);
                        console.log("data in getrecords---",articleRow);
                        return resolve(articleRow);
                    }
                    catch (error) {
                        console.log("hiiiiiiiiiii" + error)
                        return reject("No data");
                    }


          }
                    

                });
            }
            catch (error) {
                console.log("--------------" + error)
                return await error;
            }
        },

        limit: async (table, fields, where = '', whereParams = '',limit) => {
            try {
                return new Promise(async (resolve, reject) => {
                    let responseObj = {};
                    if (_.isEmpty(fields)) {
                        fields = '*';
                    }

                    // if (_.isEmpty(where)) {
                    //     where = 'id != "" ';
                    // }
                    let sql = `SELECT ${fields} from ${table} WHERE ${where} LIMIT ${limit}`;
                    if (_.isEmpty(where)) {
                        sql = `SELECT ${fields} from ${table}`;
                    }
                    console.log("Get SQL query " + sql)
                    try {
                        const [articleRow, articleFields] = await db.connection.execute(sql, [whereParams]);
                        console.log("data in getrecords---",articleRow);
                        return resolve(articleRow);
                    }
                    catch (error) {
                        console.log("hiiiiiiiiiii" + error)
                        return reject("No data");
                    }

                });
            }
            catch (error) {
                console.log("--------------" + error)
                return await error;
            }
        }

       
    }