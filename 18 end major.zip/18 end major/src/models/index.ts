const env1 = process.env.NODE_ENV || 'development';
const config = require(__dirname + './../config/config.json')[env1];

const mysql = require('mysql2/promise');

const transaction = require('node-mysql-transaction');

var session = require('express-session');
var MySQLStore = require('express-mysql-session')(session);


export const connection = mysql.createPool({
  host: config.host,
  user: config.username,
  database: config.database,
  password:config.password,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// const mysql = require('mysql');
 
// export const connection = mysql.createConnection(
//     {
//       host     : config.host,
//       user     : config.username,
//       password : config.password,
//       database : config.database,
//       connectionLimit: 10,
//       waitForConnections: true
//     }
// );


// const sessionStore = new MySQLStore({}/* session store options */, connection);


// export const trCon = transaction({
//   // mysql driver set 
//   connection: [mysql.createConnection,{
//     // mysql connection config
//     host: config.host,
//     user: config.username,
//     database: config.database,
//     password:config.password,
//     waitForConnections: true,
//     connectionLimit: 10,
//     queueLimit: 0
//   }],
  
//   // create temporary connection for increased volume of async work.
//   // if request queue became empty, 
//   // start soft removing process of the connection.
//   // recommended for normal usage.
//   dynamicConnection: 32,
  
//   // set dynamicConnection soft removing time.
//   idleConnectionCutoffTime: 1000,
  
//   // auto timeout rollback time in ms
//   // turn off is 0
//   timeout:600
// });
