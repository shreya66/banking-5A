import { Request, Response } from "express";
import authService from '../services/authService'
const validation = require('../enums/utility')

export default async (request: Request, response: Response, next) => {
    try {
        console.log("Reached Token Validator");
        const headers = request.headers;
        console.info(JSON.stringify(headers));
        if (!headers.authorization) {
            console.error(`tokenvalidator()::Access token not available in header`);
            return response.status(400).send(validation.error({}, "Authorization token not available in request headers", 400))
        }
        const decoded = await authService.verifyToken(headers.authorization);
        if (decoded['uuid'] == undefined) {
            return response.status(400).send(validation.error({}, "Invalid Token", 400))
        } else {
            console.info(`tokenvalidator()::Access token verified for uuid : ${decoded['uuid']}`);
        }
        next();
    } catch (error) {
            return validation.error({}, error, 400)
    }
};