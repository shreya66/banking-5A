import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../../../_services/authentication.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-home',
  templateUrl: './user-home.component.html',
  styleUrls: ['./user-home.component.css']
})
export class UserHomeComponent implements OnInit {
  balance: any;
  transactions:any = [];
  res :any = {};
  account_balance:String;

  constructor(private authService: AuthenticationService,
    private router: Router) { }

  ngOnInit() {
    if(localStorage.role=="qwerty"){
      this.router.navigate(['/logout']);
    }

    this.userHome();
  }

  userHome(){
    console.log("userhome");
      this.balance = [];
      
      this.authService.userHome(this.balance).subscribe((data: any) => {
        console.log(data.message);
        console.log(data.account_number);
        if(data){
          this.transactions = data.transaction
          console.log("<<<<<<<<<<<<<<<<<<<user home hits>>>>>>>>>>>>>>>>>");
          this.balance = data;
        }else{
          this.transactions = [];
        }
      });
    }
    
}
