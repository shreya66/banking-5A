

export class Cheque_list_user  {
    "cheque_number": String;
    "payer_account_number": String;
    "payee_account_number": String;
    "payee_first_name": String;
    "payee_last_name": String;
    "amount": String;
    "cheque_status": String;
    "transaction_id": String;
    "submission_date": String;
    "approved_date": String;
    "rejected_date": null;
}