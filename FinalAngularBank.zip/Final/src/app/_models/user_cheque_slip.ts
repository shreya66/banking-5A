export class UserChequeSlip {
	"payer_account_number":String;
	"payee_account_number":String;
	"payee_first_name":String;
	"payee_last_name":String;
	"amount":String;
	"cheque_number":String;
}