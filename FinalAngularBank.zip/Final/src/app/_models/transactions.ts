export class transactions  {
    "transaction_id": String;
    "transaction_timestamp": String;
    "transaction_amt":  String;
    "account_number":  String;
    "receiver_account_number":  String;
    "mode":  String;
    "reference_id":  String;
}