import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
import { NoRightClickDirective } from './_services/no-right-click.directive';
// import { RouterModule, Routes } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import{InactivityTimerComponent}from './inactivity-timer.component';
// import { routing }        from './app.routing';
  
import { AuthGuard } from './_guards/auth.guard';       
import { AlertComponent } from './_directives/alert.component';
import { ErrorInterceptor } from './_helpers/error.interceptor';
import { AuthenticationService } from './_services/authentication.service';
import {  UserService } from './_services/user.service';
import { AlertService } from './_services/alert.service';
import { TokenInterceptorService } from './_services/token-interceptor.service'
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
//website
import { WebsiteComponent } from './website/website.component';
import { RegisterComponent } from './register/register.component';
import { WebsiteNavbarComponent } from './components/website-navbar/website-navbar.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { UserNavbarComponent } from './components/user-navbar/user-navbar.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';


// import { JwtInterceptor } from './_helpers/jwt.interceptor';
//inside admindashboard
import { AdminHomeComponent } from './layouts/inside_admin_dashboard/admin-home/admin-home.component';
import { SendMoneyComponent } from './layouts/inside_user_dashboard/send-money/send-money.component';
import { CustomersComponent } from './layouts/inside_admin_dashboard/customers/customers.component';
import { NewApplicationsComponent} from './layouts/inside_admin_dashboard/new-applications/new-applications.component';
import { CloseAccountComponent} from './layouts/inside_admin_dashboard/close-account/close-account.component';

//inside userdashboard
import { UserHomeComponent } from './layouts/inside_user_dashboard/user-home/user-home.component';
import { ViewPassbookComponent } from './layouts/inside_user_dashboard/view-passbook/view-passbook.component';
import { ChequesComponent } from './layouts/inside_user_dashboard/cheques/cheques.component';
import { AddMoneyComponent } from './layouts/inside_admin_dashboard/add-money/add-money.component';



@NgModule({
  declarations: [
    AppComponent,
    AlertComponent,
    InactivityTimerComponent,
    NoRightClickDirective ,
    //website
    WebsiteComponent,
    HeaderComponent,
    FooterComponent,
    RegisterComponent,
    LoginComponent,
    LogoutComponent,
    

    //admin
    AdminHomeComponent,
    AddMoneyComponent,
    CustomersComponent,
    NewApplicationsComponent,
    CloseAccountComponent,

    // UserComponent,
    UserHomeComponent,
    SendMoneyComponent,
    ViewPassbookComponent,
    ChequesComponent,
    NavbarComponent,
    UserNavbarComponent,
    WebsiteNavbarComponent,
   
    ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
      HttpClientModule,
      // routing
        
  ],
  providers: [
              AuthGuard,AlertService,AuthenticationService,
        UserService,
        { provide: HTTP_INTERCEPTORS, useClass: TokenInterceptorService, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true }
        
        //fakebackend part 
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
