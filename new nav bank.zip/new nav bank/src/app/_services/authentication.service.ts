import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { Subject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { User } from '../_models/user';
import { Users } from '../users';
import { AddMoney } from '../_models/addMoney';
import { List } from '../_models/list';

@Injectable({ providedIn: 'root' })
export class AuthenticationService {
  private registerUrl = "http://localhost:4000/register/submit";
  private loginUrl = "http://localhost:4000/login";
  private add_moneyUrl = "http://localhost:4000/add_money";

  private show_user_list = "http://localhost:4000/admin/list";


  private currentUserSubject: BehaviorSubject<User>;
  public currentUser: Observable<User>;



  _userActionOccured: Subject<void> = new Subject();
  get userActionOccured(): Observable<void> { return this._userActionOccured.asObservable() };



  notifyUserAction() {
    this._userActionOccured.next();
  }



  constructor(private http: HttpClient,
    private router: Router) {
    this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('currentUser')));
    this.currentUser = this.currentUserSubject.asObservable();
  }

  public get currentUserValue(): User {
    return this.currentUserSubject.value;
  }


  registerUser(user: User) {
    return this.http.post<any>(this.registerUrl, user)
  }



  login(user: Users) {
    console.log('user login');
    return this.http.post<any>(this.loginUrl, user)
  }






  logOutUser() {
    console.log('user logout');
    this.router.navigate(['/website'])
  }

  // login(username: string, password: string) {
  //     return this.http.post<any>(`${config.apiUrl}/login`, { username, password })
  //         .pipe(map(user => {
  //             // login successful if there's a jwt token in the response
  //             if (user && user.token) {
  //                 // store user details and jwt token in local storage to keep user logged in between page refreshes
  //                 localStorage.setItem('currentUser', JSON.stringify(user));
  //                 this.currentUserSubject.next(user);
  //             }

  //             return user;
  //         }));
  // }

  // logout() {
  //     // remove user from local storage to log user out
  //     localStorage.removeItem('currentUser');
  //     this.currentUserSubject.next(null);
  // }


  //admin functionality services wriiten here:-

  //addmoney Service --1
  addMoney(addMoney: AddMoney) {
    return this.http.post<any>(this.add_moneyUrl, addMoney)
  }


  public getToken(): string {
    return localStorage.getItem('token');
  }

  // show users list Service --2
  private extractData(res: Response) {
    const body = res;
    return body || {};
  }

  getUsers(): Observable<any> {
    return this.http.get(this.show_user_list).pipe
      (map(this.extractData))
  };

  // 





}



// 

// import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';
// import { BehaviorSubject } from 'rxjs';
// import { Subject, Observable } from 'rxjs';
// import { map } from 'rxjs/operators';
// import { Router } from  '@angular/router';
// import { User } from '../_models/user';
// import { Users } from '../users';
// import{AddMoney} from '../_models/addMoney';

// @Injectable({ providedIn: 'root' })
// export class AuthenticationService {
//     private registerUrl = "http://localhost:4000/submit";
//     private loginUrl = "http://localhost:4000/login";
//     private add_moneyUrl = "http://localhost:4000/add_money";  

//     private currentUserSubject: BehaviorSubject<User>;
//     public currentUser: Observable<User>;



//   _userActionOccured: Subject<void> = new Subject();
//   get userActionOccured(): Observable<void> { return this._userActionOccured.asObservable() };



//   notifyUserAction() {
//     this._userActionOccured.next();
//   }



//     constructor(private http: HttpClient,
//         private router: Router) {
//         this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('currentUser')));
//         this.currentUser = this.currentUserSubject.asObservable();
//     }

//     public get currentUserValue(): User {
//         return this.currentUserSubject.value;
//     }


//     registerUser(user:User) {
//         return this.http.post<any>(this.registerUrl,user)
//       }
      //addmoney Service 



//       login(user:Users)
//       {
//         console.log('user login');
//           return this.http.post<any>(this.loginUrl,user)
//       }

//       addMoney(addMoney:AddMoney){
//         return this.http.post<any>(this.add_moneyUrl,addMoney)  }


//         public getToken(): string {
//           return localStorage.getItem('token');
//         }





//       logOutUser() {
//         console.log('user logout');
//         this.router.navigate(['/website'])
//       }



//     logout() {
//         localStorage.removeItem('currentUser');
//         this.currentUserSubject.next(null);
//     }
// }