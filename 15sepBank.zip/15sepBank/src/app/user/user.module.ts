import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserRoutingModule } from './user-routing.module';
import { HomeComponent } from './home/home.component';
import { SendMoneyComponent } from './send-money/send-money.component';
import { ViewTransactionsComponent } from './view-transactions/view-transactions.component';

@NgModule({
  declarations: [HomeComponent, SendMoneyComponent, ViewTransactionsComponent],
  imports: [
    CommonModule,
    UserRoutingModule
  ]
})
export class UserModule { }
