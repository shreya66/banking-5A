import { NgModule } from '@angular/core';
import { MatToolbarModule} from '@angular/material/toolbar';
import { 
  MatButtonModule,
  MatButtonToggleModule,
  MatIconModule,
  MatProgressSpinnerModule,
  MatSidenavModule,
  MatMenuModule
} from '@angular/material';
import { MatBadgeModule } from '@angular/material/badge';

const Material = [
  MatButtonModule,
  MatToolbarModule,
  MatButtonToggleModule,
  MatIconModule,
  MatBadgeModule,
  MatProgressSpinnerModule,
  MatToolbarModule,
  MatSidenavModule,
  MatMenuModule
];

@NgModule({
  imports: [Material],
  exports: [Material]
})
export class MaterialModule { }
