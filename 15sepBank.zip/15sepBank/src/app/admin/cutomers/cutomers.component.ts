import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cutomers',
  templateUrl: './cutomers.component.html',
  styleUrls: ['./cutomers.component.css']
})
export class CutomersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
