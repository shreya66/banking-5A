export class User {
   
    
    first_name: string;
    last_name: string;
    email:string;
    password:string;
    // confirmPassword:string;
    address:string;
    city:string;
    pincode:number;
    state:string;
    account_type :string;  
    aadhaarNumber:string;
    phone_number:string;
    branch_name :string;

}