export class AddMoney {
   
    
    "receiver_account_number":string;
    "mode":number;
    "reference_id":string;
    "money":number;


}