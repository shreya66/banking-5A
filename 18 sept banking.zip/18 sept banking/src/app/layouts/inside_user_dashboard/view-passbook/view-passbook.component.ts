import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-passbook',
  templateUrl: './view-passbook.component.html',
  styleUrls: ['./view-passbook.component.css']
})
export class ViewPassbookComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
