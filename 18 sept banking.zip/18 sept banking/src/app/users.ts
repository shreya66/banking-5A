export interface Users {
    email: string;
    password: string;
    branch_name:string;
    account_type:String;
}
