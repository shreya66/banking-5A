    // convenience getter for easy access to form fields
    import { Component, OnInit, ɵConsole } from '@angular/core';
    import { FormBuilder, FormGroup, Validators } from  '@angular/forms';
    // import { FormControl } from '@angular/forms';
    // import { AuthService } from  '../auth.service';
    import { Router } from  '@angular/router';
    
    import {MustMatch} from '../_helpers/must-match.validator'
    
    import { AlertService } from '../_services/alert.service';
    import {  UserService } from '../_services/user.service';
    import {AuthenticationService} from '../_services/authentication.service'
    import { first } from 'rxjs/operators';
    import { HttpClientModule } from '@angular/common/http'
    
    @Component({
      selector: 'app-register',
      templateUrl: './register.component.html',
      styleUrls: ['./register.component.css']
    })
    export class RegisterComponent implements OnInit {
    
      registerForm: FormGroup;
      submitted = false;
      loading = false;  
      Branch: any = ['Webdunia','Diaspark']
      Account: any = ['Savings','Current']
      constructor(
        private authService: AuthenticationService,
        private router: Router,
        private formBuilder: FormBuilder,
        private alertService: AlertService,
        private userService: UserService
      ) { }
    
      ngOnInit() {
    

        localStorage.removeItem('token');
        this.registerForm = this.formBuilder.group({
          first_name: ['', Validators.required],
          last_name: ['', Validators.required],
          email: ['', [Validators.required, Validators.email]],
          // customer_id: ['', Validators.required],
          password: ['', [Validators.required, Validators.minLength(6)]],
          // confirmPassword: ['', Validators.required],
          address: ['', Validators.required],
          city: ['', Validators.required],
          pincode: ['', Validators.required],
          state: ['', Validators.required],
          aadhaarNumber: ['', Validators.required],
          phone_number: ['', Validators.required],
          branch_name :['',Validators.required],
          account_type :['',Validators.required]
    
        
          // account_type :['', Validators.required]
    
    
          
    
      },
      //  {
      //     validator: MustMatch('password', 'confirmPassword')
      // }
      );
        
    
    
      }
    
      // changeBranch(e) {
      //   console.log(e.value)
      //   this. branch_name.setValue(e.target.value, {
      //     onlySelf: true
      //   })
      // }
    
      get  branch_name() {
        return this.registerForm.get('branch_name');
      }
    
    
      get  account_type() {
        return this.registerForm.get('account_type');
      }
    
    
    
      // registerUser() {
      //   this.authService.registerUser(this.registerForm)
      //   .subscribe(
      //     res => {
      //       localStorage.setItem('token', res.token)
      //       this.router.navigate(['/login'])
      //     },
      //     // err =>console.log(err)
       
      //   )      
      // }
    
    
    
    
        // convenience getter for easy access to form fields
        get f() { return this.registerForm.controls; }
    
    
        onSubmit() {
          this.submitted = true;
          
    console.log('shashi');
          // stop here if form is invalid
          if (this.registerForm.invalid) {
            console.log(this.registerForm)
            console.log('shashi');
              return;
          }
          this.authService.registerUser(this.registerForm.value)
          .subscribe(
          
            res => {console.log("hoiiiii",res);
              // localStorage.setItem('token', res.token),
            
            alert(res.message);
              this.router.navigate(['/login'])
            },
            // err =>console.log(err)
         
          )      
         
    
      }
    }
    





