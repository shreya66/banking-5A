import { Component, OnInit } from '@angular/core';
import { AuthenticationService} from '../../../_services/authentication.service';

@Component({
  selector: 'app-new-applications',
  templateUrl: './new-applications.component.html',
  styleUrls: ['./new-applications.component.css']
})
export class NewApplicationsComponent implements OnInit {
  applications: any = [];
  



  constructor(private authService: AuthenticationService) { }

  ngOnInit() {
    console.log("application compo loaded<<<<<<");
    this.newRequests();
  }

  newRequests() {
    console.log("<<<<<<<new request body new Application components");
    this.applications = [];
    this.authService.newRequests(this.applications).subscribe((data: any) => {
      console.log("<<<<<<<new request body new Application components");
      console.log(data);
      this.applications = data;
    });
  }

  // accept() {
  //   this.applications = [];
  //   this.authService.accept(this.applications).subscribe((data: any) => {
  //     console.log("<<<<<<<new request  Accepted>>>>>>>>>>>>>>>");
  //     console.log(data);
  //     this.applications = data;
  //   });
  // }

  accept(aadhaarNumber,account_type,branch_name,status1,index) {
   console.log(status1);
    this.authService.accept(JSON.stringify(aadhaarNumber),account_type,branch_name,status1).subscribe((data: String) => {
      console.log(data);
      this.applications.splice(index,1);
     
      // this.userList = data;
    });
  }

  // reject(item,index) {
    
  //   this.authService.reject(JSON.stringify(item)).subscribe((data: String) => {
  //     console.log(data);
  //     this.applications.splice(index,1);
     
  //     this.applications = data;
  //   });
  // }
  
  
}
