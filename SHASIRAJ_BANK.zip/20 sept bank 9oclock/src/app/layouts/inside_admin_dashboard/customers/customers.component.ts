import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../../../_services/authentication.service';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {
  userList: any = [];

  constructor(private authService: AuthenticationService) { }

  ngOnInit() { 
    console.log(">><<<<");
    
  }

  getUsers() {
    this.userList = [];
    this.authService.getUsers(this.userList).subscribe((data: any) => {
      console.log(data);
      this.userList = data;
    });
  }

  webdunia(branch_name) {
    this.authService.webdunia(branch_name).subscribe((data: any) => {
      console.log(data);
      this.userList = data;
    });
  }

  diaspark(diaspark) {
    
    this.authService.diaspark(diaspark).subscribe((data: any) => {
      console.log(data);
      this.userList = data;
    });
  }





}
  







// delete(item) {
  //   var deletedIndex;
  //   for (let index = 0; index < this.userList.length; index++) {
  //     if(item==this.userList[index]['account_number']){
  //       deletedIndex=index;
  //     }
  //   }
  //   delete this.userList[deletedIndex];
  //   this.authService.delete(item).subscribe((data: String) => {
  //     // console.log(data);

     
  //     this.userList = data;
  //   });
  // }


  // delete() {

  //   console.log(account_number);
  //   this.authService.post(account_number)
  //     .subscribe
  //     (data => console.log(account_number))
  // }

  // delete(email: string) {

  //   console.log(email);
  //   this.authService.delete(email)
  //     .subscribe
  //     (data => console.log(email))
  // }












