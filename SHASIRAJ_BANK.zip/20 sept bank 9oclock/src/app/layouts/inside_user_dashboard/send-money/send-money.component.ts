import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../../_services/authentication.service';
@Component({
  selector: 'app-send-money',
  templateUrl: './send-money.component.html',
  styleUrls: ['./send-money.component.css']
})
export class SendMoneyComponent implements OnInit {
  sendMoneyForm: FormGroup;
  submitted = false;

  constructor(
    private authService: AuthenticationService,
    private router: Router,
    private formBuilder: FormBuilder) { }

  ngOnInit() {

    this.sendMoneyForm = this.formBuilder.group({
      receiver_account_number: ['', Validators.required],
      money: ['', Validators.required],
    })
  }

  get f() { return this.sendMoneyForm.controls; }

  onSubmit() {
    this.submitted = true;

    console.log(this.sendMoneyForm);
    // stop here if form is invalid
    if (this.sendMoneyForm.invalid) {
      return;
    }

    this.authService.sendMoney(this.sendMoneyForm.value).
    subscribe(
      res => {

          if (res.status == 'error') {
            //  this.router.navigate(['/login'])
            alert(res.message);
          }
          else {
            alert(res.message);
            //  res=>(console.log,res);
          }
        }
      )
  }

}

