import { Component, OnInit } from '@angular/core';
import { AuthenticationService} from '../../../_services/authentication.service';

@Component({
  selector: 'app-view-passbook',
  templateUrl: './view-passbook.component.html',
  styleUrls: ['./view-passbook.component.css']
})
export class ViewPassbookComponent implements OnInit {
  transactions: any = [];

  

  constructor(private authService: AuthenticationService) { }

  ngOnInit() {
    console.log("<<<<<<<<<<<<<passbook loaded successfully>>>>>>>>>>>>>>");
  this.viewPassbook();
  

  } 
  
  viewPassbook() {
    this.transactions = [];
    this.authService.viewPassbook(this.transactions).subscribe((data: any) => {
      console.log(data);
      this.transactions = data;
    });
  }
  
  userPrint() {
    
    this.authService.userPrint({print}).subscribe((data: any) => {
      console.log(data);
      this.transactions = data;
    });
  }
  


  // viewPassbook(item) {
  //   console.log("<<<<<<<<<<");
  //   for (let index = 0; index < this.transactions.length; index++) {
  //     if(item==this.transactions[index]['account_number']){
  //     }
  //   }
  //   this.authService.delete(item).subscribe((data: String) => {
  //     // console.log(data);

     
  //     this.transactions = data;
  //   });
  // }
      

}
