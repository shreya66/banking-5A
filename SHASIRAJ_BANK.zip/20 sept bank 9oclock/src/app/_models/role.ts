export class role {
    "role":string;
}