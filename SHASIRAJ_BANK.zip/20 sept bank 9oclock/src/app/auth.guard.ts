import { Injectable } from '@angular/core';
import { CanActivate , Router } from '@angular/router';
import { AuthenticationService} from './_services/authentication.service';
import { role} from './_models/role';
@Injectable(
  {
  providedIn: 'root'
})
export class AuthGuard implements CanActivate { 

  constructor( private authenticationService: AuthenticationService,
              private router:Router
    )

    {}

    canActivate(): boolean {
      // var role = this.role.role;
      if(this.authenticationService.loggedInc()){
        return true;
      }
      else{
        this.router.navigate(['/website']);
        return false
      }
    }
  
}
