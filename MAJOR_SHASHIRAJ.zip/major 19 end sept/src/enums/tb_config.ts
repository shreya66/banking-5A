export default  {
    application  : "application",
    users :"users"  ,
    admin:"admin",
    account:"account",
    account_type:"account_type",
    customer_account:"customer_account",
    transaction:"transaction",
    branch:"branch",
    cheque:"cheque"
}