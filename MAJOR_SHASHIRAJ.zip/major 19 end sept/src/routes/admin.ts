import * as express from "express";
const bodyParser = require('body-parser');
import admin from '../controllers/admin'
var router = express.Router();
router.use(bodyParser.json());
import tokenValidator from "../middlewares/tokenValidator";



router.post('/approval',tokenValidator, async (req, res) => {
    try {
      
      var output = await admin.approve(req.body,req.query);
    
          res.json(output);
  
    } catch (err) {
      res.json(err);
    }
  })

  router.post('/add_money',tokenValidator , async (req, res) => {
    try {
      
      var output = await admin.add_money(req.body,req.headers);
    
      res.json(output);
  
    } catch (err) {
      res.json(err);
    }
  })
  
  router.post('/close',tokenValidator , async (req, res) => {
    try {
      
      var output = await admin.close(req.body,req.headers);
    
      res.json(output);
  
    } catch (err) {
      res.json(err);
    }
  })

  router.post('/transactions',tokenValidator , async (req, res) => {
    try {
      
      var output = await admin.transactions(req.body,req.headers);
    
      // res.status(output.code).json(output);
      res.json(output)
  
    } catch (err) {
      res.json(err);
    }
  })
  
  router.post('/list',tokenValidator , async (req, res) => {
    try {
      
      var output = await admin.list(req.body,req.headers);
      console.log(output)
    
      // res.status(output.code).json(output);
      res.json(output)
    } catch (err) {
      res.json(err);
    }
  })

  router.post('/cheque_list',tokenValidator , async (req, res) => {
    try {
      
      var output = await admin.cheque_list(req.body,req.headers);
      console.log(output)
    
      // res.status(output.code).json(output);
      res.json(output)
  
    } catch (err) {
      res.json(err);
    }
  })

  router.post('/applicants_list',tokenValidator , async (req, res) => {
    try {
      
      var output = await admin.applicants_list(req.body,req.headers);
      console.log(output)
    
      // res.status(output.code).json(output);
      res.json(output)
  
    } catch (err) {
      res.json(err);
    }
  })

  router.post('/unlock',tokenValidator , async (req, res) => {
    try {
      
      var output = await admin.unlock(req.body,req.headers);
    
      res.json(output);
  
    } catch (err) {
      res.json(err);
    }
  })

  router.post('/check_cheque',tokenValidator , async (req, res) => {
    try {
      
      var output = await admin.check_cheque(req.body,req.headers);
    
      res.json(output);
  
    } catch (err) {
      res.json(err);
    }
  })
  
  router.post('/print', tokenValidator,async (req, res) => {
    try {

      var output = await admin.print(req.body,req.headers);

      res.json(output);

    } catch (err) {
      res.json(err);
    }
  })


  
  module.exports = router;