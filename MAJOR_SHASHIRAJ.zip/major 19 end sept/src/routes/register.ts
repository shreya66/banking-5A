import * as express from "express";
const bodyParser = require('body-parser');
import register from '../controllers/register'
var router = express.Router();
router.use(bodyParser.json());


  router.post('/submit', async (req, res) => {
    try {
      
      var output = await register.submit(req.body,req.headers);
    
      res.json(output);
  
    } catch (err) {
      res.send(err);
    }
  })
  
  module.exports = router;