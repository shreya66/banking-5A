import * as Joi from '@hapi/joi'
import tables from '../enums/tb_config'
import authService from '../services/authService'
import * as _ from "lodash";
import verify from '../controllers/auth'
var validation = require('../enums/utility');
const dbAction = require('../models/sqlModel');
import moment from 'moment'
const excel = require('exceljs');
let uuid = require("uuid");

export default class{

static async send_money(req,header){

    try{
        console.log("===========================================REACHED SEND MONEY=====================================")
        const schema = Joi.object().keys({
            receiver_account_number:Joi.string().min(10).max(10).required(),
            money:Joi.number().integer().min(1).max(100000).required()
        }).with('receiver_account_number','money');
        const { error, value } = Joi.validate(req, schema, { abortEarly: false });
        if (error) {
            console.log(error.details[0].message);
            return {
                code: 400,
                status: "error",
                message: `input Error: ${error.details[0].message}`,
                role:"user"
            }

        };

        try{
            let val1 = { receiver_account_number: _.get(req, 'receiver_account_number', ""),money: _.get(req, 'money', "") }
            const decrypt = await authService.decryptToken(header.authorization);
            let account_number = decrypt.account_number;
            const check = await verify.check_acc(account_number);
            const check1  = await verify.check_acc(val1.receiver_account_number);
            if(check && check1 ){
                console.log("===========================================REACHED CHECK=====================================")

                const result = await dbAction.getRecords(tables.account, 'account_number,acc_type_id,account_balance,account_overdraft', `account_number = '${account_number}' `, '')


                if(parseInt(result[0].account_balance)< val1.money && result[0].acc_type_id == 1){

                    return{
                        code:412,//Precondition
                        status:"error",
                        message:"Not enough funds",
                        role:"user"
                    }
                
                }

                else if(parseInt(result[0].account_balance) == 0 && result[0].acc_type_id == 2){

                    if(result[0].account_overdraft<val1.money){
                        return {
                            code:412,//Precondition
                        status:"error",
                        message:"Not enough funds and Overdraft limit reached",
                        role:"user"
                        }
                    }

                    else{
                        let updated_overdraft = parseInt(result[0].account_overdraft) - parseInt(val1.money);
                        const result5 = await dbAction.getRecords(tables.account, 'account_balance', `account_number = '${account_number}' `, '')
                        let updated_balance = parseInt(result5[0].account_balance)- parseInt(val1.money);

                        console.log("===========================================REACHED ELSE====================================")

                        const output = await dbAction.updateRecords(tables.account, 'account_balance = ?', 'account_number = ?',
                        [updated_balance, account_number]);

                        const output2 = await dbAction.updateRecords(tables.account, 'account_overdraft = ?', 'account_number = ?',
                        [updated_overdraft, account_number]);

                        const result1 = await dbAction.getRecords(tables.account, 'account_balance', `account_number = '${val1.receiver_account_number}' `, '')

                        let updated_balance_receiver = parseInt(result1[0].account_balance) + parseInt(val1.money) ;

                        const output3 = await dbAction.updateRecords(tables.account, 'account_balance = ?', 'account_number = ?',
                        [updated_balance_receiver, val1.receiver_account_number]);

                        let trans_id = uuid.v4();
                        let reference_id = uuid.v4();
    
                        const output4 = await dbAction.insertRecords(tables.transaction, 'transaction_id,transaction_timestamp,transaction_amt,account_number,receiver_account_number,mode,reference_id', "?,?,?,?,?,?,?",
                        [trans_id, moment().format('YYYY-MM-DD HH:mm:ss'), val1.money,account_number, val1.receiver_account_number, "NEFT", reference_id]);

                        const result2 = await dbAction.getRecords(tables.account, 'account_balance', `account_number = '${account_number}' `, '')

                        return{
                            code:200,
                            status:"success",
                            message: `${val1.money} successfully transferred to ${val1.receiver_account_number}`,
                            role:"user",
                            account_balance: result2[0].account_balance
                        }

                    }

                }

               else if(result[0].acc_type_id == 2 && parseInt(result[0].account_balance)<val1.money ){

                    let total_balance = parseInt(result[0].account_balance) + parseInt(result[0].account_overdraft)
    
                    if(total_balance<val1.money){

                        return {
                        code:412,//Precondition
                        status:"error",
                        message:"Not enough funds and Overdraft limit reached",
                        role:"user"
                        }

                    }

                    else{

                        let remaining_balance = parseInt(val1.money) - parseInt(result[0].account_balance);
                        let updated_overdraft = parseInt(result[0].account_overdraft) - remaining_balance;

                        const output3 = await dbAction.updateRecords(tables.account, 'account_balance = ?', 'account_number = ?',
                            [-remaining_balance, account_number]);

                            const output4 = await dbAction.updateRecords(tables.account, 'account_overdraft = ?', 'account_number = ?',
                            [updated_overdraft, account_number]);

                            const result1 = await dbAction.getRecords(tables.account, 'account_balance', `account_number = '${val1.receiver_account_number}' `, '')

                            let updated_balance_receiver = parseInt(result1[0].account_balance) + parseInt(val1.money) ;

                            const output5 = await dbAction.updateRecords(tables.account, 'account_balance = ?', 'account_number = ?',
                            [updated_balance_receiver, val1.receiver_account_number]);

                            let trans_id = uuid.v4();
                            let reference_id = uuid.v4();
        
                            const output6 = await dbAction.insertRecords(tables.transaction, 'transaction_id,transaction_timestamp,transaction_amt,account_number,receiver_account_number,mode,reference_id', "?,?,?,?,?,?,?",
                            [trans_id, moment().format('YYYY-MM-DD HH:mm:ss'), val1.money,account_number, val1.receiver_account_number, "NEFT", reference_id]);

                            const result2 = await dbAction.getRecords(tables.account, 'account_balance', `account_number = '${account_number}' `, '')
                            return{
                                code:200,
                                status:"success",
                                message: `${val1.money} successfully transferred to ${val1.receiver_account_number}`,
                                role:"user",
                                account_balance: result2[0].account_balance
                            }


                    }

                    

                }

                else{


                    let updated_balance = parseInt(result[0].account_balance) - parseInt(val1.money);
    
                    const output = await dbAction.updateRecords(tables.account, 'account_balance = ?', 'account_number = ?',
                        [updated_balance, account_number]);

                    const result1 = await dbAction.getRecords(tables.account, 'account_balance', `account_number = '${val1.receiver_account_number}' `, '')

                    let updated_balance_receiver = parseInt(result1[0].account_balance) + parseInt(val1.money) ;

                    const output2 = await dbAction.updateRecords(tables.account, 'account_balance = ?', 'account_number = ?',
                            [updated_balance_receiver, val1.receiver_account_number]);

                            let trans_id = uuid.v4();
                            let reference_id = uuid.v4();
        
                            const output4 = await dbAction.insertRecords(tables.transaction, 'transaction_id,transaction_timestamp,transaction_amt,account_number,receiver_account_number,mode,reference_id', "?,?,?,?,?,?,?",
                            [trans_id, moment().format('YYYY-MM-DD HH:mm:ss'), val1.money,account_number, val1.receiver_account_number, "NEFT", reference_id]);

                            const result2 = await dbAction.getRecords(tables.account, 'account_balance', `account_number = '${account_number}' `, '')

                            return{
                                code:200,
                                status:"success",
                                message: `${val1.money} successfully transferred to ${val1.receiver_account_number}`,
                                role:"user",
                                account_balance: result2[0].account_balance
                            }

                }

            }

            else{
                return {
                code:400,
                status:"error",
                message:"invalid Account Number or Account inactive",
                role:"user"
                }
                
            }
            

        }
        catch(error){
            return {
                code:500,
            status:"error",
            message:"Database Error",
            role:"user"
            }
        }


    }
    catch(error){

        return {
            code:500,
        status:"error",
        message:"Internal Server Error",
        role:"user"
        }


    }
}

static async transactions(req,header){

    
        try{
            const decrypt = await authService.decryptToken(header.authorization);
            let account_number = decrypt.account_number;
            const check = await verify.check_acc(account_number);
            if(check ){
        const result5 = await dbAction.getRecords(tables.transaction, '*', `account_number = '${account_number}' `, '')
        const result2 = await dbAction.getRecords(tables.account, 'account_balance', `account_number = '${account_number}' `, '')
        // return {
        //     code:200,
        //     status:"success",
        //     message: `List of Transactions fetched successfully`,
        //     role:"user",
        //     transactions:result5,
        //     account_balance: result2[0].account_balance
        // }
        return result5;
        }

        else{
            return{
                code:400,
                status:"error",
                message:"Account Inactive",
                role:"user"
            }
        }
    }
        catch(error){

            return{
                code:500,
                status:"error",
                message:"Database Error",
                role:"user"
            }
            

        }
    

}

static async cheque(req,header){

    try{
        const schema = Joi.object().keys({
            payer_account_number: Joi.string().min(10).max(10).required(),
            payee_account_number: Joi.string().min(10).max(10).required(),
            payee_first_name: Joi.string().required(),
            payee_last_name: Joi.string().required(),
            amount:Joi.number().integer().min(1).max(100000).required(),
            cheque_number: Joi.string().required()
        }).with('payer_account_number',['payee_account_number','payee_first_name','payee_last_name','amount','cheque_number']);
        const { error, value } = Joi.validate(req, schema, { abortEarly: false });
        if (error) {
            console.log(error.details[0].message);
            return {
                code: 400,
                status: "error",
                message: `input Error: ${error.details[0].message}`,
                role:"user"
            }

        };

        try{
            let val1 = { payer_account_number: _.get(req, 'payer_account_number', ""), payee_account_number: _.get(req, 'payee_account_number', ""), payee_first_name: _.get(req, 'payee_first_name', ""), payee_last_name: _.get(req, 'payee_last_name', ""), amount: _.get(req, 'amount', ""), cheque_number: _.get(req, 'cheque_number', "")}
 
            const output4 = await dbAction.insertRecords(tables.cheque, 'cheque_number,payer_account_number,payee_account_number,payee_first_name,payee_last_name,amount,cheque_status,submission_date', "?,?,?,?,?,?,?,?",
            [val1.cheque_number,val1.payer_account_number,val1.payee_account_number,val1.payee_first_name,val1.payee_last_name,val1.amount,"sent for clearance",moment().format('YYYY-MM-DD HH:mm:ss')]);
            return{
                code:200,
                status:"success",
                message:"Slip Generated Successfully",
                role:"user"
            }
    }
        catch(error){

            return{
                code:500,
                status:"error",
                message:"Database Error",
                role:"user"
            }
            

        }
    }

    catch(error){
        return{
            code:500,
            status:"error",
            message:"Internal Server Error",
            role:"user"
        }


    }


}


static async print(req, header) {
    try{
        const schema = Joi.object({
            start_date:Joi.string(),
            end_date:Joi.string()
        }).with('start_date','end_date')
        const { error, value } = Joi.validate(req, schema, { abortEarly: false });
        if (error) {
            console.log(error.details[0].message);
            return {
                code: 400,
                status: "error",
                message: `input Error: ${error.details[0].message}`,
                role:"user"
            }

        };
        let val1 = {start_date: _.get(req, 'start_date', ""),end_date: _.get(req, 'end_date', "") };
        const decrypt = await authService.decryptToken(header.authorization);
        let account_number = decrypt.account_number;

            const result = await dbAction.range(tables.transaction,account_number, val1.start_date, val1.end_date);
                
                const transactions = JSON.parse(JSON.stringify(result));
                let workbook = new excel.Workbook(); 
    let worksheet = workbook.addWorksheet('transactions'); 
    worksheet.columns = [
        { header: 'Transaction Id', key: 'transaction_id', width: 50 },
        { header: 'Date of Transaction', key: 'transaction_timestamp', width: 30 },
        { header: 'Amount', key: 'transaction_amt', width: 30},
        { header: 'Payer acc', key: 'account_number', width: 30},
        { header: 'Payee acc', key: 'receiver_account_number', width: 30},
        { header: 'Payment Mode', key: 'mode', width: 30},
        { header: 'Reference_Id', key: 'reference_id', width: 30},
        
    ];
 
    worksheet.addRows(transactions);

    let path =  await workbook.xlsx.writeFile("transactions1.xlsx")

    const result2 = await dbAction.getRecords(tables.account, 'account_balance', `account_number = '${account_number}' `, '')
    
    return {
        code: 200,
        status: "success",
        message: "Report Downloaded succesfully",
        role:"user",
        account_balance: result2[0].account_balance
    };


    }
    catch(error){
        return{
            code:500,
            status:"error",
            message:"Internal Server Error",
            role:"user"
        }


    }
}

static async check_balance(req, header) {
    try{

        const decrypt = await authService.decryptToken(header.authorization);
        let account_number = decrypt.account_number;

        try{
            const result2 = await dbAction.getRecords(tables.account, 'account_balance', `account_number = '${account_number}' `, '')
            return{
                code:200,
                status:"success",
                message: `Account balance is ${result2[0].account_balance} `,
                role:"user",
                account_balance: result2[0].account_balance
            }
            
        }
        catch(error){
            return{
                code:500,
                status:"error",
                message:"Database Error",
                role:"user"
            }

        }

    }
    catch(error){
        return{
            code:500,
            status:"error",
            message:"Internal Server Error",
            role:"user"
        }
    }
}

static async cheque_list(req, header) {
    
    try {
        const decrypt = await authService.decryptToken(header.authorization);
        let account_number = decrypt.account_number;
        const result = await dbAction.getRecords(tables.cheque, '*', `payee_account_number = '${account_number}' `, '')

        console.log(result)
        // return {
        //     code: 200,
        //     status: "success",
        //     message: "Successfully Fetched User List",
        //     role:"admin",
        //     list:result4
        // }
        return result;
    }

    catch (error) {

        return {
            code: 500,
            status: "error",
            message: "Database Error",
            role:"user"
        }

    }

}



}