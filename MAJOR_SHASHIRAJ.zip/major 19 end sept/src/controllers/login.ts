import * as Joi from '@hapi/joi'
import tables from '../enums/tb_config'
import authService from '../services/authService'
import * as _ from "lodash";
const dbAction = require('../models/sqlModel');





export default class {

    static async validate(req, header) {
        try {
            
            const schema = Joi.object().keys({
                customer_id: Joi.string().min(6).required(),
                password: Joi.string().regex(/^[a-zA-Z0-9]{6,16}$/).min(6).required(),
                account_type:Joi.string().required(),
                branch_name:Joi.string().required()
            }).with('customer_id',['password','account_type','branch_name'])
            const { error, value } = Joi.validate(req, schema, { abortEarly: false });
            if (error) {
                console.log(error.details[0].message);
                return {
                    code: 400,
                    status: "error",
                    message: `input Error: ${error.details[0].message}`
                }

            };
            let val1 = { customer_id: _.get(req, 'customer_id', ""), password: _.get(req, 'password', ""),account_type: _.get(req, 'account_type', ""),branch_name: _.get(req, 'branch_name', "") };
            try {
                let pass = await authService.encryptPass(val1.password);
                var result2 = await dbAction.getRecords(tables.admin, '*', `customer_id = '${val1.customer_id}' AND password = '${pass}' `, '');
                if (!result2.length){
                    var result = await dbAction.getRecords(tables.users, '*', `customer_id = '${val1.customer_id}' AND password = '${pass}' `, '');
                    if(result.length){
                    
                        var result3 = await dbAction.getRecords(tables.account_type, 'acc_type_id', `account_type = '${val1.account_type}' `, '');
                        var result4 = await dbAction.getRecords(tables.branch, 'branch_id', `branch_name = '${val1.branch_name}' `, '');  
                        var result5 = await dbAction.getRecords(tables.customer_account, '*', `customer_id = '${val1.customer_id}' AND acc_type_id = '${result3[0].acc_type_id}' AND branch_id = '${result4[0].branch_id}' AND status = 'Active'`, '');
                        if(result5.length){
                            
                          
                                var result6 = await dbAction.getRecords(tables.account, 'account_balance', `account_number = '${result5[0].account_number}' `, '');

                                const uuid = require('uuidv4').default;
                                let id = uuid();
                                
                                var uuid1 = await authService.encrypt(id);
                                uuid1.account_number = result5[0].account_number;
                                const token = await authService.createToken(uuid1);
                                
                                const output = await dbAction.updateRecords(tables.users, 'locked = ?', 'customer_id = ?',
                                            [0, val1.customer_id]);
                
                                var result77 = await dbAction.limit(tables.transaction, '*', `account_number = '${result5[0].account_number}' `, '',5);
                            
                                return {
                                    code: 200,
                                    status: "success",
                                    role: "user",
                                    message: "User Logged In",
                                    token: token,
                                    account_type: val1.account_type,
                                    balance:result6[0].account_balance,
                                    first_name:result[0].first_name,
                                    last_name:result[0].last_name,
                                    address:result[0].address,
                                    pincode:result[0].pincode,
                                    phone_number:result[0].phone_number,
                                    email:result[0].email,
                                    city:result[0].city,
                                    state:result[0].state,
                                    aadhaarNumber:result[0].aadhaarNumber,
                                    status1:result[0].status,
                                    branch_name:val1.branch_name,
                                    customer_id:val1.customer_id,
                                    account_number:result5[0].account_number,
                                    transaction:result77
                                }

                                

                        }
                        else{

                            if(result[0].locked == 2)
                            {
                                return {
                                    code: 403,
                                    status: "error",
                                    message: "You have exhausted your login attempts.Please visit the branch to unlock your account."
                                }

                            }

                            else{

                                var result12 = await dbAction.getRecords(tables.customer_account, '*', `customer_id = '${val1.customer_id}' AND acc_type_id = '${result3[0].acc_type_id}' AND branch_id = '${result4[0].branch_id}' AND status = 'Inactive'`, '');
                                if(result12.length){

                                    return {
                                        code: 403,
                                        status: "error",
                                        message: ` Customer ID: ${val1.customer_id} is deactivated.Contact bank for details.`
                                    }

                                }
                                var result7 = await dbAction.getRecords(tables.users, 'locked', `customer_id = '${val1.customer_id}' `, '');
                                let updated_locked = parseInt(result7[0].locked) + 1;
                                const output = await dbAction.updateRecords(tables.users, 'locked = ?', 'customer_id = ?',
                                [updated_locked, val1.customer_id]);

                                let remaining = 2 - parseInt(result7[0].locked);

                                return {
                                    code: 401,//Unauthorized
                                    status: "error",
                                    message: `Incorrect details.You are left with ${remaining} more login attempts` 
                                }


                            }
                        }
                    }

                    else{
                        var result10 = await dbAction.getRecords(tables.users, '*', `customer_id = '${val1.customer_id}' `, '');

                        if(result10.length && result10[0].status == "Active" ){

                            if(result10[0].locked == 2)
                            {
                                return {
                                    code: 403,//Forbidden
                                    status: "error",
                                    message: "You have exhausted your login attempts.Please visit the branch to unlock your account."
                                }

                            }
                            else{

                                let updated_locked = parseInt(result10[0].locked) + 1;
                                
                                const output = await dbAction.updateRecords(tables.users, 'locked = ?', 'customer_id = ?',
                                [updated_locked, val1.customer_id]);


                                let remaining = 2 - parseInt(result10[0].locked);
    
                                return {
                                    code: 401,
                                    status: "error",
                                    message: `Incorrect details.You are left with ${remaining} more login attempts`

                            }
                        
                            }

                        }


                        else{
                            return {
                                code: 401,
                                status: "error",
                                message: `Customer with Customer ID: ${val1.customer_id} does not exist for chosen branch : ${val1.branch_name}`
                            }
            

                        }

                    


                    }

                  

                }
                   

            } catch (error) {
                console.log(error);
                return {
                    code: 500,
                    status: "error",
                    message: "Database Error"
                }
            }


    
             if (result2.length && result2[0].acc_type_id == "2" && result2[0].branch_id == "1") {
          
                const uuid = require('uuidv4').default;
                let id = uuid();
                
                var uuid1 = await authService.encrypt(id);
                const token = await authService.createToken(uuid1);
                var result11 = await dbAction.limit(tables.transaction, '*', `account_number = '1000000000' `, '',5);
                return {
                    code: 200,
                    status: "success",
                    role: "admin",
                    message: "Admin Logged In",
                    token: token,
                    account_type: val1.account_type,
                    transaction:result11
   
                }
            }



            else {
              
                return {
                    code: 401,
                    status: "error",
                    message: `Customer with Customer ID: ${val1.customer_id} does not exist for chosen branch : ${val1.branch_name}`
                }



            }




        }

        catch (error) {
            return {
                
                code: 500,
                status: "error",
                message: "Internal Server Error"
            }
        }
    }
}