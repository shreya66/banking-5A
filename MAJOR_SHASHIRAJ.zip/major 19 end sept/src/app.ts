var createError = require('http-errors');
import express from "express";
import scheduler from "./middlewares/scheduler";
var path = require('path');
var cookieParser = require('cookie-parser');
var session = require('express-session');
var indexRouter = require('./routes/index');
var adminRouter = require('./routes/admin');
var loginRouter = require('./routes/login');
var authRouter = require('./routes/auth');
var regRouter = require('./routes/register');
var cors = require('cors');
var userRouter = require('./routes/user');
var sessionStore = require("./models/index");
const cron = require("node-cron");
var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

// app.use(logger('dev'));
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
// app.use('/users', usersRouter);
app.use('/admin',adminRouter);
app.use('/login',loginRouter);
app.use('/auth', authRouter);
app.use('/register', regRouter);
app.use('/user', userRouter);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err:any, req:any, res:any, next:any) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

try {
 
  // cron.schedule("* * * * *", function() {
  //   console.log("---------------------");
  //   console.log("Running Cron Job");

  //   let output = scheduler.check_savings();
  //   let output2 = scheduler.check_current();

  // });

  const server =app.listen(4000, () =>{ console.log(`Example app listening on ${4000}!`)
}); 

}
catch(error){
  console.debug(error)
}

module.exports = app;
