const env1 = process.env.NODE_ENV || 'development';
const config = require(__dirname + './../config/config.json')[env1];

const mysql = require('mysql2/promise');

const transaction = require('node-mysql-transaction');

var session = require('express-session');
var MySQLStore = require('express-mysql-session')(session);


export const connection = mysql.createPool({
  host: config.host,
  user: config.username,
  database: config.database,
  password:config.password,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

