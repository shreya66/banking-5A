import { NgModule, ApplicationModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddMoneyComponent } from './add-money/add-money.component';
import { CutomersComponent } from './cutomers/cutomers.component';
import { HomeComponent } from './home/home.component';
import { ApplicationsComponent } from './applications/applications.component';

const routes: Routes = [
  { path: '',component:HomeComponent },
  { path: 'home',component:HomeComponent },
  { path:'add_money', component: AddMoneyComponent},
  { path: 'applications', component: ApplicationsComponent},
  { path: 'customers', component: CutomersComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
