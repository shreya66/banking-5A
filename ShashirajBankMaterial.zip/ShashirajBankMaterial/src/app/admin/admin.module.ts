import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminRoutingModule } from './admin-routing.module';
import { AddMoneyComponent } from './add-money/add-money.component';
import { CutomersComponent } from './cutomers/cutomers.component';
import { ApplicationsComponent } from './applications/applications.component';
import { HomeComponent } from './home/home.component';
import { MaterialModule } from '../material/material.module';

@NgModule({
  declarations: [
                 AddMoneyComponent,
                 CutomersComponent,
                 ApplicationsComponent,
                 HomeComponent
      ],

  imports: [
    CommonModule,
    AdminRoutingModule,
    MaterialModule
    
  ]
})
export class AdminModule { }
