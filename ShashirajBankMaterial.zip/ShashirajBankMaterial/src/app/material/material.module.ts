import { NgModule } from '@angular/core';
import { MatToolbarModule} from '@angular/material/toolbar';
import { 
  MatButtonModule,
  MatButtonToggleModule,
  MatIconModule,
  MatProgressSpinnerModule,
  MatSidenavModule,
  MatMenuModule,MatAutocompleteModule,
  
  
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatExpansionModule,
  MatGridListModule,
  
  MatInputModule,
  MatListModule,
  
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatTableModule,
  MatTabsModule,
  
  MatTooltipModule,
  MatStepperModule,
} from '@angular/material';
import { MatBadgeModule } from '@angular/material/badge';

const Material = [
  MatButtonModule,
  MatToolbarModule,
  MatButtonToggleModule,
  MatIconModule,
  MatBadgeModule,
  MatProgressSpinnerModule,
  MatToolbarModule,
  MatSidenavModule,
  MatMenuModule,
  MatAutocompleteModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,
  MatStepperModule,
  
];

@NgModule({
  imports: [Material],
  exports: [Material]
})
export class MaterialModule { }
