import { Component, OnInit } from '@angular/core';

import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, Validators,FormControl } from '@angular/forms';
import { first } from 'rxjs/operators';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AuthenticationService } from '../../_services';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {

    hide = true;
    formGroup: FormGroup;

    constructor(private formBuilder: FormBuilder) { }
  
    ngOnInit() {
      this.createForm();
    }
  
    createForm() {
      this.formGroup = this.formBuilder.group({
        'username': ['', Validators.required],
        'password': ['', Validators.required],
      });
    }
  
  
    getError(el) {
      switch (el) {
        case 'user':
          if (this.formGroup.get('username').hasError('required')) {
            return 'Username required';
          }
          break;
        case 'pass':
          if (this.formGroup.get('password').hasError('required')) {
            return 'Password required';
          }
          break;
        default:
          return '';
      }
    }
    //ending of form stakblitz



  // loginForm: FormGroup;
  // loading = false;
  // submitted = false;
  // returnUrl: string;
  // error = '';

//   constructor(

    // private formBuilder: FormBuilder,
    //     private route: ActivatedRoute,
    //     private router: Router,
    //     private authenticationService: AuthenticationService
//   ) {}

     // redirect to home if already logged in
  //    if (this.authenticationService.currentUserValue) { 
  //     this.router.navigate(['/']);
  //  }

//   ngOnInit() { }

  //   this.loginForm = this.formBuilder.group({
  //     username: ['', Validators.required],
  //     password: ['', Validators.required]
  // });

 // // get return url from route parameters or default to '/'
 //true
//   this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
// }

// get f() { return this.loginForm.controls; 
//   }

  //for submitting login
//   onSubmit() {
//     this.submitted = true;

//     if (this.loginForm.invalid) {
//         return;
//     }

//     this.loading = true;
//     this.authenticationService.login(this.f.username.value, this.f.password.value)
//         .pipe(first())
//         .subscribe(
//             data => {
//                 this.router.navigate([this.returnUrl]);
//             },
//             error => {
//                 this.error = error;
//                 this.loading = false;
//             });
// }

}
