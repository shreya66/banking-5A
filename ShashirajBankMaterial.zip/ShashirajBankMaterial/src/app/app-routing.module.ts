import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
// import { HomeComponent } from './website/home/home.component';
// import { HeaderComponent } from './components/header/header.component';


  const appRoutes: Routes = [
    {
      path: 'website',
      loadChildren: () => import('./website/website.module').then(mod => mod.WebsiteModule)
    },

    {
      path: 'user',
      loadChildren: () => import('./user/user.module').then(mod => mod.UserModule)
    },

    {
      path: 'admin',
      loadChildren: () => import('./admin/admin.module').then(mod => mod.AdminModule)
    },

    {
      path: '',
      redirectTo: 'website',
      pathMatch: 'full'
    }
];


   


@NgModule({
  imports: [RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
