import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../../../_services/authentication.service';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {
  userList: any = [];

  constructor(private authService: AuthenticationService) { }

  ngOnInit() { }

  getUsers() {
    this.userList = [];
    this.authService.getUsers(this.userList).subscribe((data: any) => {
      console.log(data);
      this.userList = data;
    });
  }

  delete() {
    this.userList = [];
    this.authService.delete(this.userList).subscribe((data: any) => {
      console.log(data);
      this.userList = data;
    });
  }


  // delete() {

  //   console.log(account_number);
  //   this.authService.post(account_number)
  //     .subscribe
  //     (data => console.log(account_number))
  // }

  // delete(email: string) {

  //   console.log(email);
  //   this.authService.delete(email)
  //     .subscribe
  //     (data => console.log(email))
  // }

}







//




// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-customers',
//   templateUrl: './customers.component.html',
//   styleUrls: ['./customers.component.css']
// })
// export class CustomersComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }



//

