import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-applications',
  templateUrl: './new-applications.component.html',
  styleUrls: ['./new-applications.component.css']
})
export class NewApplicationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
