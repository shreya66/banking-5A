
import { Component, OnInit } from '@angular/core';
import {AuthenticationService} from '../../../_services/authentication.service';
import { Router } from  '@angular/router';
import { FormBuilder, FormGroup, Validators } from  '@angular/forms';

@Component({
  selector: 'app-add-money',
  templateUrl: './add-money.component.html',
  styleUrls: ['./add-money.component.css']
})
export class AddMoneyComponent implements OnInit {
  addMoneyForm :FormGroup;
  submitted = false;
  loading = false;


  constructor( private authService: AuthenticationService,
    private formBuilder: FormBuilder,

    ) { }

  ngOnInit() {
    this.addMoneyForm = this.formBuilder.group({
      "receiver_account_number":['', Validators.required,Validators.minLength(10),Validators.maxLength(10)],
      "mode":['', Validators.required],
      "reference_id":['', Validators.required],
      "money":['', Validators.required]
      
    })
  }



omSubmit()
{
  this.submitted = true;

    // stop here if form is invalid
    if (this.addMoneyForm.invalid) {
      console.log(this.addMoneyForm)
        return;
    }


this.authService.addMoney(this.addMoneyForm.value).
subscribe(
  res=>{
   if (res.status =="error")
   {
     alert("please enter valid details and try again");
   }
   else{
     res=>(console.log,res);
   }
  }
)
}
}











// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-add-money',
//   templateUrl: './add-money.component.html',
//   styleUrls: ['./add-money.component.css']
// })
// export class AddMoneyComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }
