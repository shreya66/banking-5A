import { Component, OnInit,HostListener} from '@angular/core';
import { Subscription } from 'rxjs';
import { FormBuilder, FormGroup, Validators } from  '@angular/forms';
import { Router } from  '@angular/router';
import { Users } from  '../users';
import {AuthenticationService} from '../_services/authentication.service'
// import { userInfo } from 'os';
// import {MessageService}from '../_services/message.service'
 @Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

 



  loginForm: FormGroup;
  submitted = false;
  Branch: any = ['Webdunia','Diaspark']
  Account: any = ['Savings','Current']
  constructor(
    private authService: AuthenticationService,
     private router: Router,
    //  private messageService: MessageService,
     private formBuilder: FormBuilder) 
     {
    
 }


     @HostListener('document:keyup', ['$event'])
     @HostListener('document:click', ['$event'])
     @HostListener('document:wheel', ['$event'])
     resetTimer(){
      this.authService.notifyUserAction()
    }

  ngOnInit() {
   
     this.loginForm = this.formBuilder.group({
            // username: ['', Validators.required],
            password: ['', Validators.required],
            account_type:['',Validators.required],
            branch_name:['',Validators.required],
            customer_id:['',Validators.required],
            

        });
        
  
  }

  get  branch_name() {
    return this.loginForm.get('branch_name');
  }



  get  account_type() {
    return this.loginForm.get('account_type');
  }






  get f() { return this.loginForm.controls; }
  // resetTimer(){
  //   this.authService.notifyUserAction()
  // }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.loginForm.invalid) {
        return;
    }
    this.authService.login(this.loginForm.value)
    .subscribe(

      res=>{
        console.log('yes this hits',res);
       if(res.status=='error')
         { this.router.navigate(['/login'])
          alert("invalid credentials");
      }

       else if(res.user=="admin")
       {
        localStorage.setItem('token',res.token)
        this.router.navigate(['/admin'])
      }

      else if(res.user=="user")
      {
       localStorage.setItem('token',res.token)
       this.router.navigate(['/user'])
     }
      
    }


    )


    // alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.loginForm.value));
    // var data = this.loginForm.value;
    // const formData = new FormData();
    // console.log(data);
    // this.router.navigate(['/user']);
    // this.loading = true;
    //   this.userService.register(this.registerForm.value)
    //       .pipe(first())
    //       .subscribe(
    //           data => {
    //               this.alertService.success('Registration successful', true);
    //               // console.log(value);
    //               this.router.navigate(['/website']);
                  
    //           },
    //           error => {
    //               this.alertService.error(error);
    //               this.loading = false;
    //           });

}
}