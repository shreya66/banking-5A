import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './auth.guard';

//website
import { WebsiteComponent } from './website/website.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
// import { UserComponent } from './user/user.component';



// admin components inside admin dashboard
import {AdminHomeComponent } from './layouts/inside_admin_dashboard/admin-home/admin-home.component';
import {AddMoneyComponent } from './layouts/inside_admin_dashboard/add-money/add-money.component';
import {CloseAccountComponent } from './layouts/inside_admin_dashboard/close-account/close-account.component';
import {CustomersComponent } from './layouts/inside_admin_dashboard/customers/customers.component';
import {NewApplicationsComponent } from './layouts/inside_admin_dashboard/new-applications/new-applications.component';


// user components inside user dashboard
import { ChequesComponent } from './layouts/inside_user_dashboard/cheques/cheques.component';
import { UserHomeComponent } from './layouts/inside_user_dashboard/user-home/user-home.component';
import { SendMoneyComponent } from './layouts/inside_user_dashboard/send-money/send-money.component';
import { ViewPassbookComponent } from './layouts/inside_user_dashboard/view-passbook/view-passbook.component';


const routes: Routes = [
  { path: '', pathMatch:"full", component: WebsiteComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'login', component: LoginComponent },
  { path: 'user', component: UserHomeComponent },
  { path: 'logout', component: LogoutComponent},
  //canActivate: [AuthGuard] 

  //admin routes through inside_admin_dashboard
  { path: 'add_money', component:AddMoneyComponent},
  { path: 'customers', component:CustomersComponent},
  {path: 'close_account', component:CloseAccountComponent},
  {path: 'new_applications', component:NewApplicationsComponent},
  {path: 'admin', component:AdminHomeComponent},
  
  //user routes through inside_user_dashboard
  { path: 'send_money', component:SendMoneyComponent},
  { path: 'cheques', component:ChequesComponent},
  { path: 'send_money', component:SendMoneyComponent},
  { path: 'view_passbook', component:ViewPassbookComponent},

  { path: '**', redirectTo: 'website' }
];



@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
