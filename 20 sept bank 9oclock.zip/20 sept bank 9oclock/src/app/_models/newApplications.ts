export class NewApplications {
    aadhaarNumber:String;
    account_type:String;
    branch_name:String;
}