export class List {
    "branch_name":string;
}