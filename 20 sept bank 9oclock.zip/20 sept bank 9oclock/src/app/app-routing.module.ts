import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './auth.guard';

//website
import { WebsiteComponent } from './website/website.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
// import { UserComponent } from './user/user.component';



// admin components inside admin dashboard
import {AdminHomeComponent } from './layouts/inside_admin_dashboard/admin-home/admin-home.component';
import {AddMoneyComponent } from './layouts/inside_admin_dashboard/add-money/add-money.component';
import {CloseAccountComponent } from './layouts/inside_admin_dashboard/close-account/close-account.component';
import {CustomersComponent } from './layouts/inside_admin_dashboard/customers/customers.component';
import {NewApplicationsComponent } from './layouts/inside_admin_dashboard/new-applications/new-applications.component';


// user components inside user dashboard
import { ChequesComponent } from './layouts/inside_user_dashboard/cheques/cheques.component';
import { UserHomeComponent } from './layouts/inside_user_dashboard/user-home/user-home.component';
import { SendMoneyComponent } from './layouts/inside_user_dashboard/send-money/send-money.component';
import { ViewPassbookComponent } from './layouts/inside_user_dashboard/view-passbook/view-passbook.component';


const routes: Routes = [
  { path: '', pathMatch:"full", component: WebsiteComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'login', component: LoginComponent },
  { path: 'website', component: WebsiteComponent },
  { path: 'logout', component: LogoutComponent},
  //canActivate: [AuthGuard] 

  //admin routes through inside_admin_dashboard
  {path: 'admin/admin_home', component:AdminHomeComponent},
  { path: 'admin/add_money', component:AddMoneyComponent , canActivate : [AuthGuard]},
  { path: 'admin/customers', component:CustomersComponent, canActivate : [AuthGuard]},
  {path: 'admin/close_account', component:CloseAccountComponent, canActivate : [AuthGuard]},
  {path: 'admin/new_applications', component:NewApplicationsComponent, canActivate : [AuthGuard]},
  {path: 'admin', component:AdminHomeComponent, canActivate : [AuthGuard]},
  
  //user routes through inside_user_dashboard
  { path: 'user', component:UserHomeComponent, canActivate : [AuthGuard]},
  { path: 'user/user_home', component:UserHomeComponent, canActivate : [AuthGuard]},
  { path: 'user/cheques', component:ChequesComponent, canActivate : [AuthGuard]},
  { path: 'user/send_money', component:SendMoneyComponent, canActivate : [AuthGuard]},
  { path: 'user/view_passbook', component:ViewPassbookComponent, canActivate : [AuthGuard]},
  // { path: 'user/view_passbook', component:},

  // { path: '**', redirectTo: 'website' }
];



@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
