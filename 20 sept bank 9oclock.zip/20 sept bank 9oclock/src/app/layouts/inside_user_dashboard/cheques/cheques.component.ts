import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from  '@angular/forms';
import { Router } from  '@angular/router';
import {AuthenticationService} from '../../../_services/authentication.service';



@Component({
  selector: 'app-cheques',
  templateUrl: './cheques.component.html',
  styleUrls: ['./cheques.component.css']
})
export class ChequesComponent implements OnInit {
  chequeSlipForm: FormGroup;
  submitted = false;
  chequeList: any = [];

  constructor( private authService: AuthenticationService,
    private router: Router,
   //  private messageService: MessageService,
    private formBuilder: FormBuilder) { }

  ngOnInit() {

    this.chequeSlipForm = this.formBuilder.group({
      // username: ['', Validators.required],
      payer_account_number:['',Validators.required, Validators.minLength(10)],
      payee_account_number:['',Validators.required, Validators.minLength(10)],
      payee_first_name:['',Validators.required],
      payee_last_name:['',Validators.required],
      amount:['',Validators.required],
      cheque_number:['',Validators.required],

  });


  }

  get f() { return this.chequeSlipForm.controls; }

  onSubmit() {
    this.submitted = true;
 console.log(this.chequeSlipForm);
    // stop here if form is invalid
    if (this.chequeSlipForm.invalid) {
        return;
    }

    this.authService.generateSlip(this.chequeSlipForm.value)
    .subscribe(

      res=>{
        console.log('user generate cheque slip hits',res);
        
       if(res.status=='error')
         { 
          //  this.router.navigate(['/login'])
          alert("invalid ");
      }
      else {
        console.log("this is without error");
        this.router.navigate(['/admin/cheques'])
      }

      })


    }
    
    viewCheques() {
      this.chequeList = [];
      this.authService.viewCheques(this.chequeList).subscribe((data: any) => {
        console.log(data);
        this.chequeList = data;
      });
    }




}
