import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../../../_services/authentication.service';


@Component({
  selector: 'app-user-home',
  templateUrl: './user-home.component.html',
  styleUrls: ['./user-home.component.css']
})
export class UserHomeComponent implements OnInit {
  balance: any = [];
  constructor(private authService: AuthenticationService) { }

  ngOnInit() {

    this.userHome();
  }

  userHome(){
    console.log("userhome");
      this.balance = [];
      this.authService.userHome(this.balance).subscribe((data: any) => {
        console.log(data);
        console.log("<<<<<<<<<<<<<<<<<<<user home hits>>>>>>>>>>>>>>>>>");
        this.balance = data;
      });
    }
    

  
}
