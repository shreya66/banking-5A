
import { Component, OnInit } from '@angular/core';
import {AuthenticationService} from '../../../_services/authentication.service';
import { Router } from  '@angular/router';
import { FormBuilder, FormGroup, Validators } from  '@angular/forms';

@Component({
  selector: 'app-add-money',
  templateUrl: './add-money.component.html',
  styleUrls: ['./add-money.component.css']
})
export class AddMoneyComponent implements OnInit {
  addMoneyForm :FormGroup;
  submitted = false;


  constructor( private authService: AuthenticationService,
    private formBuilder: FormBuilder ) { }

  ngOnInit() {

    console.log("sssssss");
    this.addMoneyForm = this.formBuilder.group({
      receiver_account_number:['',Validators.required],
      mode:['',Validators.required],
      reference_id:['',Validators.required],
      money:['',Validators.required]
    })
  }

  get f() { return this.addMoneyForm.controls; }

onSubmit()
{ 
  console.log("on submit");
  this.submitted = true;

    // stop here if form is invalid
    if (this.addMoneyForm.invalid) {
      console.log("<>><><><<><addmoney component");
      console.log(this.addMoneyForm)
        return;
    }


this.authService.addMoney(this.addMoneyForm.value).
subscribe(
  res=>{
    console.log('yes add money hits',res)
   if (res.status =="error")
   {
     alert("please enter valid details and try again");
   }
   else{
     res=>(console.log,res);
   }
  }
)
}



}











// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-add-money',
//   templateUrl: './add-money.component.html',
//   styleUrls: ['./add-money.component.css']
// })
// export class AddMoneyComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }
