import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { Subject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { User } from '../_models/user';
import { Users } from '../users';
import { AddMoney } from '../_models/addMoney';
import { List } from '../_models/list';
import { Customers } from '../_models/customers';
import { role } from '../_models/role';
import { transactions } from '../_models/transactions';
import { NewApplications } from  '../_models/newApplications';
import { Balance } from  '../_models/balance';
import { Cheque_list_user} from '../_models/cheque_list_user';

@Injectable({ providedIn: 'root' })
export class AuthenticationService {
  private registerUrl = "http://localhost:4000/register/submit";
  private loginUrl = "http://localhost:4000/login";

  //user api
  private send_money = "http://localhost:4000/user/send_money";
  private user_transactions = "http://localhost:4000/user/transactions";
  private user_check_balance = "http://localhost:4000/user/check_balance";
  private user_cheque_slip = "http://localhost:4000/user/cheque";
  private user_print = "http://localhost:4000/user/print";
  private admin_print = "http://localhost:4000/admin/print";
  private cheque_list = "http://localhost:4000/user/cheque_list";
  
  //admin api

  private add_moneyUrl = "http://localhost:4000/admin/add_money";
  private show_user_list = "http://localhost:4000/admin/list";
  private close_userUrl = "http://localhost:4000/admin/close";
  private requests = "http://localhost:4000/admin/applicants_list";
  private admin_cheque = "http://localhost:4000/admin/cheque_list";
  private acceptreq = "http://localhost:4000/admin/approval";
  private reject = "http://localhost:4000/admin/reject";
  private currentUserSubject: BehaviorSubject<User>;
  public currentUser: Observable<User>;



  _userActionOccured: Subject<void> = new Subject();
  get userActionOccured(): Observable<void> { return this._userActionOccured.asObservable() };



  notifyUserAction() {
    this._userActionOccured.next();
  }



  constructor(private http: HttpClient,
    private router: Router) {
    this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('currentUser')));
    this.currentUser = this.currentUserSubject.asObservable();
  }

  public get currentUserValue(): User {
    return this.currentUserSubject.value;
  }


  registerUser(user: User) {
    return this.http.post<any>(this.registerUrl, user)
  }



  login(user: Users) {
    console.log('user login');
    return this.http.post<any>(this.loginUrl, user)
  }
  

  //for token Validation
  loggedInc() {
    return !!localStorage.getItem('token')
    // this.router.navigate['/website'];
  }

  getToken(){
    return localStorage.getItem('token');
  }



  logOutUser() {
    console.log('user logout');
    this.router.navigate(['/website'])
  }



  //admin functionality services wriiten here:-
  addMoney(addMoney: AddMoney) {
    return this.http.post<any>(this.add_moneyUrl, addMoney)
  }

   
  newRequests(newApplications: NewApplications) {
    return this.http.post<any>(this.requests,newApplications)
  }

  accept(aadhaarNumber,account_type,branch_name) {
    console.log(">>>>>>>>>>>>>>>>>>>>>Accepted reached>>>>>>>>>>>>>>>>")
    return this.http.post<any>(this.acceptreq,{aadhaarNumber,account_type,branch_name});

  }


  delete(account_number) {
    console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>",typeof account_number)
    return this.http.post<any>(this.close_userUrl , {account_number:account_number});

  }


  // show users list Service --2
  private extractData(res: Response) {
    const body = res;
    return body || {};
  }

  // getUsers(any:<any>): Observable<any> {
  //   return this.http.post(this.show_user_list,any) 
  // };

  // 
  getUsers(any) {
    console.log('user customers');
    return this.http.post<any>(this.show_user_list, any)
  }

  viewPassbook(transaction: transactions) {
    console.log('transaction works');
    return this.http.post<any>(this.user_transactions, transaction)
  }

  viewCheques(chequeList: Cheque_list_user) {
    console.log('checklist user works');
    return this.http.post<any>(this.cheque_list, chequeList)
  }

  userHome(balance:Balance){
    console.log('check balance works');
    return this.http.post<any>(this.user_check_balance ,balance)
  }



  sendMoney(any) {
    console.log("send money");
    return this.http.post<any>(this.send_money,any)
  }

  generateSlip(any) {
    console.log("user Cheque slip authentication works");
    return this.http.post<any>(this.user_cheque_slip,any)
  }


}


