import { Component, OnInit,HostListener} from '@angular/core';
import { Subscription } from 'rxjs';
import { FormBuilder, FormGroup, Validators } from  '@angular/forms';
import { Router } from  '@angular/router';
import { Users } from  '../users';
import {AuthenticationService} from '../_services/authentication.service';
// import { userInfo } from 'os';
// import {MessageService}from '../_services/message.service'
 @Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  

  loginForm: FormGroup;
  submitted = false;
  Branch: any = ['Webdunia','Diaspark']
  Account: any = ['Savings','Current']
  constructor(
    private authService: AuthenticationService,
     private router: Router,
    //  private messageService: MessageService,
     private formBuilder: FormBuilder) 
     {
 }


     @HostListener('document:keyup', ['$event'])
     @HostListener('document:click', ['$event'])
     @HostListener('document:wheel', ['$event'])
     resetTimer(){
      this.authService.notifyUserAction()
    }

  ngOnInit() {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
     this.loginForm = this.formBuilder.group({
            // username: ['', Validators.required],
            password: ['', Validators.required],
            account_type:['',Validators.required],
            branch_name:['',Validators.required],
            customer_id:['',Validators.required],
            

        });
        
  
  }

  get  branch_name() {
    return this.loginForm.get('branch_name');
  }



  get  account_type() {
    return this.loginForm.get('account_type');
  }






  get f() { return this.loginForm.controls; }
  // resetTimer(){
  //   this.authService.notifyUserAction()
  // }

  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.loginForm.invalid) {
      console.log("<<<<<<login res");
      
        return;
    }
    this.authService.login(this.loginForm.value)
    .subscribe(
      res=>{
        console.log('yes this hits',res);
       if(res.status=='error')
         { 
           console.log("<<<<<<<<<<<<<<<<<error")
           alert(res.message);
          //  this.router.navigate(['/login'])
      }

       else if(res.role=="admin")
       {
        localStorage.setItem('token',res.token),
        localStorage.setItem('role',res.role)
       
        this.router.navigate(['/admin'])
      }

      else if(res.role=="user")
      {
       localStorage.setItem('token',res.token),
       localStorage.setItem('role',res.role)
      
       this.router.navigate(['/user'])
     }
      
    }


    )
    
}
}