export class SendMoney {
   
    "receiver_account_number":string;
    "money":number;
}