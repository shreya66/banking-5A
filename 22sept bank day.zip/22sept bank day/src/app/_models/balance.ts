export class Balance {
   
    
    "account_balance":string;
   

}