import { Component, OnInit } from '@angular/core';
import {AuthenticationService} from '../../../_services/authentication.service';
import { Router } from '@angular/router';



@Component({
  selector: 'app-close-account',
  templateUrl: './close-account.component.html',
  styleUrls: ['./close-account.component.css']
})
export class CloseAccountComponent implements OnInit {
  userList: any = [];
  constructor(private authService: AuthenticationService,
    private router: Router) { }

  ngOnInit() {
    if(localStorage.role=="user"){
      this.router.navigate(['/website']);
    }
    this.getUsers();
  }
  getUsers() {
    this.userList = [];
    this.authService.getUsers(this.userList).subscribe((data: any) => {
      console.log(data);
      this.userList = data;
    });
  }

  delete(item,index) {
    // var deletedIndex;
    // for (let index = 0; index < this.userList.length; index++) {
    //   if(item==this.userList[index]['account_number']){
    //     deletedIndex=index;
    //   }
    // }
    // delete this.userList[deletedIndex];
    this.authService.delete(JSON.stringify(item)).subscribe((data: String) => {
      console.log(data);
      this.userList.splice(index,1);
     
      // this.userList = data;
    });
  }

}
