import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule} from '@angular/forms';
// import { RouterModule, Routes } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import{InactivityTimerComponent}from './inactivity-timer.component';
// import { routing }        from './app.routing';
  
import { AuthGuard } from './_guards/auth.guard';       
import { AlertComponent } from './_directives/alert.component';
import { JwtInterceptor } from './_helpers/jwt.interceptor';
import { ErrorInterceptor } from './_helpers/error.interceptor';
import { AuthenticationService } from './_services/authentication.service';
import {  UserService } from './_services/user.service';
import { AlertService } from './_services/alert.service';

import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
//website
import { WebsiteComponent } from './website/website.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';

import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard.component';
import { UserDashboardComponent} from './components/user-dashboard/user-dashboard.component';
//inside admindashboard
import { }from './layouts/inside_admin_dashboard/admin-home/admin-home.component';
import { SendMoneyComponent } from './layouts/inside_user_dashboard/send-money/send-money.component';
import { CustomersComponent } from './layouts/inside_admin_dashboard/customers/customers.component';
import { NewApplicationsComponent} from './layouts/inside_admin_dashboard/new-applications/new-applications.component';
import { CloseAccountComponent} from './layouts/inside_admin_dashboard/close-account/close-account.component';

//inside userdashboard
import { UserHomeComponent } from './layouts/inside_user_dashboard/user-home/user-home.component';
import { ViewPassbookComponent } from './layouts/inside_user_dashboard/view-passbook/view-passbook.component';
import { ChequesComponent } from './layouts/inside_user_dashboard/cheques/cheques.component';
import { AddMoneyComponent } from './layouts/inside_admin_dashboard/add-money/add-money.component';
import { AdminHomeComponent } from './layouts/inside_admin_dashboard/admin-home/admin-home.component';



@NgModule({
  declarations: [
    AppComponent,
    AlertComponent,
    InactivityTimerComponent,
    //website
    WebsiteComponent,
    HeaderComponent,
    FooterComponent,
    RegisterComponent,
    LoginComponent,
    LogoutComponent,
    UserDashboardComponent,
    AdminDashboardComponent,

    //admin
    AdminHomeComponent,
    AddMoneyComponent,
    CustomersComponent,
    NewApplicationsComponent,
    CloseAccountComponent,

    // UserComponent,
    UserHomeComponent,
    SendMoneyComponent,
    ViewPassbookComponent,
    ChequesComponent,
   
    ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
      HttpClientModule,
      // routing
        
  ],
  providers: [
    AuthGuard,
        AlertService,
        AuthenticationService,
        UserService,
        { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true }
        
        //fakebackend part 
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
