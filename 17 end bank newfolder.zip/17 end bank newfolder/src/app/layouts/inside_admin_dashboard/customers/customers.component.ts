import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from '../../../_services/authentication.service';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {
  userList: any = [];

  constructor(private authService: AuthenticationService) { }

  ngOnInit() { }

  getUsers() {
    this.userList = [];
    this.authService.getUsers().subscribe((data: any) => {
      console.log(data);
      this.userList = data;
    });
  }
}







//




// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-customers',
//   templateUrl: './customers.component.html',
//   styleUrls: ['./customers.component.css']
// })
// export class CustomersComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }



//

